# Mission 2031 — Native Android starter

React Native / Expo mobile app scaffold. Current MVP includes daily task list, daily report journal, pillar overview, CWA display, university funding notes tracker, and weekly review. Data persists locally on the phone with AsyncStorage.

## Build an installable APK (cloud build)
1. Install Node.js LTS and Git.
2. In this folder, run `npm install`.
3. Run `npx expo login` and log into your Expo account.
4. Run `npx eas-cli build:configure` and follow setup. Replace the placeholder EAS project ID in `app.json` with the one EAS gives you (or remove the `extra.eas.projectId` entry if configure handles it).
5. Build: `npx eas-cli build -p android --profile preview`
6. EAS provides a build URL. Download the APK to your phone and install it. It can then be copied to other Android phones.

## Run locally
`npm start`, then scan the QR code using Expo Go. Expo Go is for development preview; it is not the standalone APK.

## Notes
- This scaffold does not contain cloud sync or backup/restore yet.
- University statuses/notes are manually editable. No funding claims have been researched or verified in-app.
- Daily task completion is date-scoped based on the device's UTC date in this initial version; local-time handling will be refined in the next iteration.
