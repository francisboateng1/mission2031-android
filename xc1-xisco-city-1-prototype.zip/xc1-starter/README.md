# XC 1 — Xisco City 1

**Playable Prototype 0.1 — District One**

An original, mobile-first, browser-playable 3D open-world action-adventure prototype by Xisco Labs. XC 1 is inspired by the freedom and mission structure of open-world games, but uses its own fictional setting, identity, characters and assets.

## What works in this prototype

- A small procedural 3D city district with roads, sidewalks, buildings, trees, streetlights and pedestrians.
- Third-person player movement, running and jumping.
- A drivable starter car with simple steering, acceleration, braking and collision response.
- Entering and exiting the vehicle.
- A first mission: collect three data drives, then deliver them to the safehouse.
- Mission progress, cash rewards, minimap, in-game clock and touch controls.
- Responsive mobile interface and installable PWA shell.

## Run locally

Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev -- --host 0.0.0.0
```

Open the local Vite URL. In GitHub Codespaces, use the **Ports** tab and open forwarded port 5173 in a browser.

For a production static build:

```bash
npm run build
```

The deployable site is written to `dist/`.

## Controls

### Desktop
- `W A S D` or arrow keys — move / drive
- `Shift` — run
- `E` — interact, enter or exit car
- `Space` — jump on foot / brake in vehicle
- Drag the world — orbit the camera
- `Esc` — pause

### Android / touch
- Left virtual joystick — move / steer
- `RUN` — hold to run
- `JUMP` — jump / brake
- `ACT` — collect, enter or exit / deliver
- Drag the upper world area to orbit the camera

## Android installation

Deploy the `dist/` folder to an HTTPS static host (for example, GitHub Pages, Netlify or Vercel). Open the hosted URL in Chrome on Android, open the browser menu, and choose **Install app** or **Add to Home screen**. This produces an installable web app (PWA), not a native APK.

A native Android release can be made later by packaging the game with Capacitor or rebuilding the game client in Unity. The current project is deliberately a playable vertical slice, not a finished GTA-scale game.

## Current limitations

- Placeholder geometry instead of final character/vehicle art.
- Small single-player district; no combat, traffic simulation, interiors, save slots or multiplayer yet.
- Simple arcade vehicle handling and collision boundaries.
- Three.js is loaded from a pinned jsDelivr CDN URL, so the first launch requires an internet connection.
- The service worker caches the local game shell after the first successful load, but does not guarantee offline operation because Three.js is external.

## Production roadmap

1. Replace primitives with optimized, original 3D character and vehicle assets.
2. Improve vehicle physics, pedestrian navigation, traffic and world collision.
3. Add mission scripting, dialogue, checkpoints, save/load and map discovery.
4. Build art direction, sound, music, accessibility and Android performance profiles.
5. Expand District One only after the vertical slice performs reliably on target phones.

## Project identity

- Title: **XC 1 — Xisco City 1**
- Studio: **Xisco Labs**
- Prototype version: **0.1.0**
- Genre: **Open-world action-adventure**
