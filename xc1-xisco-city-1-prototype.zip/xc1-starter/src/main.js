import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.170.0/build/three.module.js';

const root = document.querySelector('#game-root');
const isMobile = matchMedia('(max-width: 700px)').matches || 'ontouchstart' in window;
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x93aaa3);
scene.fog = new THREE.Fog(0x93aaa3, 105, 290);
const camera = new THREE.PerspectiveCamera(62, innerWidth / innerHeight, .1, 500);
const renderer = new THREE.WebGLRenderer({antialias: !isMobile, powerPreference: 'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio, isMobile ? 1.35 : 1.8));
renderer.setSize(innerWidth, innerHeight);
renderer.shadowMap.enabled = !isMobile;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
root.appendChild(renderer.domElement);

const hemi = new THREE.HemisphereLight(0xdcebe0, 0x485653, 2.0); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe0ae, 2.2); sun.position.set(-65, 105, 55); sun.castShadow = !isMobile; sun.shadow.mapSize.set(1024,1024); sun.shadow.camera.left=-115; sun.shadow.camera.right=115; sun.shadow.camera.top=115; sun.shadow.camera.bottom=-115; scene.add(sun);
const mat = (color, roughness=.9, metalness=0) => new THREE.MeshStandardMaterial({color, roughness, metalness});
const materials = {
 road: mat(0x293438), asphalt: mat(0x364246), sidewalk:mat(0xb2ad9b), grass:mat(0x526f58),
 white:mat(0xe6e3d5), yellow:mat(0xe9c96a), glass:mat(0x83aaa8,.32,.25), dark:mat(0x1c292c),
 building:[0x9d998d,0x7e8984,0xc0ad91,0x627b7b,0xb3a28f,0x8a8e85,0x697c77].map(c=>mat(c)),
 trim:mat(0x404b47), tree:mat(0x315b48), trunk:mat(0x66503b), neon:mat(0xc7f36b,.45,.1),
};
const ground = new THREE.Mesh(new THREE.PlaneGeometry(420,420), materials.grass); ground.rotation.x=-Math.PI/2; ground.position.y=-.16; ground.receiveShadow=true; scene.add(ground);
const colliders=[];
const rand=(a,b)=>a+Math.random()*(b-a);
function box(w,h,d,material,x,y,z, opts={}){const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),material);m.position.set(x,y,z);m.castShadow=!!opts.shadow;m.receiveShadow=true;scene.add(m);return m;}
function addCollider(x,z,w,d){colliders.push({minX:x-w/2,maxX:x+w/2,minZ:z-d/2,maxZ:z+d/2});}
function makeRoads(){
  const extent=136, step=34, road=11, sidewalkW=2.4;
  box(290,.12,290,materials.grass,0,-.11,0);
  for(let i=-4;i<=4;i++){
    const p=i*step;
    box(290,.12,road,materials.road,0,-.035,p);
    box(road,.12,290,materials.road,p,-.034,0);
    box(290,.14,sidewalkW,materials.sidewalk,0,.025,p-road/2-sidewalkW/2);
    box(290,.14,sidewalkW,materials.sidewalk,0,.025,p+road/2+sidewalkW/2);
    box(sidewalkW,.14,290,materials.sidewalk,p-road/2-sidewalkW/2,.025,0);
    box(sidewalkW,.14,290,materials.sidewalk,p+road/2+sidewalkW/2,.025,0);
    for(let k=-4;k<=4;k++){
      const q=k*step;
      if(i!==0){box(2.6,.025,.22,materials.yellow,p,.035,q+road*.30);box(2.6,.025,.22,materials.yellow,p,.035,q-road*.30);}
      if(k!==0){box(.22,.025,2.6,materials.yellow,q,.035,p+road*.30);box(.22,.025,2.6,materials.yellow,q,.035,p-road*.30);}
    }
  }
}
makeRoads();

// Compact, original District One: a procedural grid of low-rise and mid-rise blocks.
function makeBuilding(x,z,w,d,h,index){
  const body=materials.building[index%materials.building.length];
  const base=box(w,h,d,body,x,h/2,z,{shadow:true});addCollider(x,z,w+.8,d+.8);
  // Roof lip and rooftop machinery give silhouettes more character.
  box(w+.35,.45,d+.35,materials.trim,x,h+.22,z);
  if(h>15){box(w*.30,1.1,d*.28,materials.dark,x+w*.18,h+.95,z-d*.12);box(w*.19,.8,d*.2,materials.white,x-w*.2,h+.8,z+d*.15);}
  // Simple facade windows, restrained for mobile performance.
  const floors=Math.min(6,Math.floor(h/3.2));
  const cols=Math.max(2,Math.floor(w/2.8));
  for(let f=0;f<floors;f++) for(let c=0;c<cols;c++){
    const wx=x-w/2+(c+.5)*w/cols; const wy=2.0+f*3.1;
    box(.78,1.12,.07,materials.glass,wx,wy,z-d/2-.045);
    box(.78,1.12,.07,materials.glass,wx,wy,z+d/2+.045);
  }
  // Ground-floor entry and a bright shop fascia.
  box(Math.min(w*.48,4.5),.7,.12,materials.neon,x,.8,z-d/2-.1);
}
let buildingIndex=0;
for(let gx=-3;gx<=3;gx++)for(let gz=-3;gz<=3;gz++){
  if(Math.abs(gx)<=0&&Math.abs(gz)<=0)continue;
  const cx=gx*34, cz=gz*34;
  // A small number of open courtyards keep the district readable.
  if((gx===-2&&gz===1)||(gx===2&&gz===-1)){
    box(18,.12,18,materials.grass,cx,.02,cz);
    for(let n=0;n<4;n++)makeTree(cx+rand(-7,7),cz+rand(-7,7),rand(.8,1.15));
    continue;
  }
  const count=(Math.abs(gx)+Math.abs(gz)>4)?1:2;
  for(let n=0;n<count;n++){
    const x=cx+(count===1?0:(n===0?-6.6:6.6));
    const z=cz+rand(-2.2,2.2);
    const w=count===1?rand(13,17):rand(8.4,10.5);
    const d=count===1?rand(13,17):rand(10,14);
    const h=rand(8, count===1?22:34);
    makeBuilding(x,z,w,d,h,buildingIndex++);
  }
}
function makeTree(x,z,s=1){
  const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.18*s,.25*s,2.1*s,6),materials.trunk);trunk.position.set(x,1.05*s,z);scene.add(trunk);
  const crown=new THREE.Mesh(new THREE.IcosahedronGeometry(1.15*s,1),materials.tree);crown.position.set(x,2.35*s,z);crown.castShadow=true;scene.add(crown);
}
// Street trees and lamp posts along selected sidewalks.
for(let i=-3;i<=3;i++)for(let j=-3;j<=3;j++){
  if(Math.random()<.48){const x=i*34+rand(-10,10),z=j*34+rand(-14,-9);makeTree(x,z,rand(.7,1));}
  if(Math.random()<.38){const x=i*34+rand(-14,-9),z=j*34+rand(-10,10);makeTree(x,z,rand(.65,.9));}
}
function makeLamp(x,z){
  const pole=new THREE.Mesh(new THREE.CylinderGeometry(.07,.1,5.5,6),materials.dark);pole.position.set(x,2.75,z);scene.add(pole);
  const arm=box(1.1,.09,.09,materials.dark,x+.48,5.25,z);arm.rotation.z=-.12;
  const bulb=new THREE.Mesh(new THREE.SphereGeometry(.19,8,8),new THREE.MeshBasicMaterial({color:0xffe6a1}));bulb.position.set(x+.95,5.12,z);scene.add(bulb);
}
for(let t=-3;t<=3;t++){makeLamp(t*34+8,-17);makeLamp(t*34-8,17);}

// City centre plaza and unmistakable XC landmark.
box(20,.16,17,mat(0x8c9a89),0,.06,0);
for(let i=0;i<4;i++){const treeX=-8+i*5.2;makeTree(treeX,5,.8);}
const signStand=box(12,4,.65,materials.dark,0,4.5,-10,{shadow:true});
box(10.8,2.8,.15,materials.neon,0,4.7,-10.42);
// Lettering is canvas-generated, so no external image assets are required.
function textTexture(lines, fg='#142017', bg='#c7f36b'){
 const c=document.createElement('canvas');c.width=768;c.height=256;const ctx=c.getContext('2d');ctx.fillStyle=bg;ctx.fillRect(0,0,c.width,c.height);ctx.fillStyle=fg;ctx.textAlign='center';ctx.font='900 104px Arial';ctx.fillText(lines[0],384,112);ctx.font='700 40px Arial';ctx.fillText(lines[1],384,174);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;
}
const signMat=new THREE.MeshBasicMaterial({map:textTexture(['XISCO CITY','DISTRICT ONE']),toneMapped:false});
const signFace=new THREE.Mesh(new THREE.PlaneGeometry(10.5,3.45),signMat);signFace.position.set(0,4.7,-10.53);scene.add(signFace);

// Player character — original placeholder hero, designed for later replacement with a rigged model.
const player=new THREE.Group();
const skin=mat(0x9b6545), shirt=mat(0x273e3b), pants=mat(0x202a31), shoes=mat(0xd2d7cb);
const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.82,4,8),shirt);torso.position.y=1.42;torso.castShadow=true;player.add(torso);
const head=new THREE.Mesh(new THREE.SphereGeometry(.34,12,10),skin);head.position.y=2.26;head.castShadow=true;player.add(head);
const hair=new THREE.Mesh(new THREE.SphereGeometry(.35,10,8,0,Math.PI*2,0,Math.PI*.48),mat(0x18201e));hair.position.set(0,2.39,0);player.add(hair);
const armL=new THREE.Mesh(new THREE.CapsuleGeometry(.13,.63,3,6),shirt);armL.position.set(-.58,1.48,0);armL.rotation.z=-.12;player.add(armL);
const armR=armL.clone();armR.position.x=.58;armR.rotation.z=.12;player.add(armR);
const legL=new THREE.Mesh(new THREE.CapsuleGeometry(.17,.65,3,6),pants);legL.position.set(-.22,.48,0);player.add(legL);
const legR=legL.clone();legR.position.x=.22;player.add(legR);
const shoeL=box(.32,.16,.58,shoes,-.22,.14,.08);player.add(shoeL);shoeL.position.set(-.22,.14,.08);
const shoeR=shoeL.clone();shoeR.position.x=.22;player.add(shoeR);
player.position.set(0,0,6);scene.add(player);

// Drivable starter car, built from simple geometry. Later releases can swap in a detailed vehicle mesh.
const car=new THREE.Group();
const carPaint=mat(0x8d3027,.38,.25), rubber=mat(0x111719), trimMat=mat(0x252d30), windowMat=mat(0x547477,.25,.22);
const chassis=box(2.35,.72,4.55,carPaint,0,.77,0);car.add(chassis);
const cabin=box(1.82,.85,2.25,windowMat,0,1.48,-.18);car.add(cabin);
const roof=box(1.88,.15,2.3,carPaint,0,1.96,-.18);car.add(roof);
for(const x of [-1.13,1.13])for(const z of [-1.48,1.48]){
 const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.43,.43,.25,12),rubber);wheel.rotation.z=Math.PI/2;wheel.position.set(x,.48,z);wheel.castShadow=true;car.add(wheel);
 const hub=new THREE.Mesh(new THREE.CylinderGeometry(.17,.17,.27,10),materials.white);hub.rotation.z=Math.PI/2;hub.position.set(x*1.01,.48,z);car.add(hub);
}
for(const x of [-.76,.76]){const light=box(.48,.22,.08,materials.white,x,.77,2.3);car.add(light);const tail=box(.4,.2,.08,mat(0xc83b32),x,.76,-2.3);car.add(tail);}
car.position.set(5,0,7);car.rotation.y=Math.PI;scene.add(car);

// Pedestrians, decorative and non-combatant in this first vertical slice.
const pedestrians=[];
for(let i=0;i<10;i++){
 const npc=new THREE.Group();const coat=mat([0x304b58,0x9b7748,0x6f7965,0x6b4d64][i%4]);
 const body=new THREE.Mesh(new THREE.CapsuleGeometry(.28,.58,3,6),coat);body.position.y=1.05;npc.add(body);
 const face=new THREE.Mesh(new THREE.SphereGeometry(.2,8,8),skin);face.position.y=1.7;npc.add(face);
 const x=rand(-105,105),z=rand(-105,105);npc.position.set(x,0,z);scene.add(npc);pedestrians.push({mesh:npc,origin:new THREE.Vector3(x,0,z),phase:rand(0,6.28),speed:rand(.25,.65)});
}

// Mission objects: collect three data drives and deliver them to the safehouse marker.
const drivePositions=[new THREE.Vector3(-34,0,49),new THREE.Vector3(68,0,-5),new THREE.Vector3(0,0,102)];
const drives=[];
function makeDrive(pos,index){
 const group=new THREE.Group();const ring=new THREE.Mesh(new THREE.TorusGeometry(.62,.12,8,18),materials.neon);ring.rotation.x=Math.PI/2;ring.position.y=1.25;group.add(ring);
 const core=new THREE.Mesh(new THREE.OctahedronGeometry(.36,0),new THREE.MeshStandardMaterial({color:0xd9ff9a,emissive:0x6a9f2d,emissiveIntensity:1.2,metalness:.55,roughness:.25}));core.position.y=1.25;group.add(core);group.position.copy(pos);group.userData={index};scene.add(group);drives.push(group);
 const beam=new THREE.Mesh(new THREE.CylinderGeometry(.03,.65,7,12,1,true),new THREE.MeshBasicMaterial({color:0xc7f36b,transparent:true,opacity:.12,side:THREE.DoubleSide}));beam.position.set(pos.x,3.5,pos.z);scene.add(beam);
}
drivePositions.forEach(makeDrive);
const safehouse=new THREE.Group();const safeRing=new THREE.Mesh(new THREE.TorusGeometry(2.2,.15,10,32),materials.neon);safeRing.rotation.x=Math.PI/2;safeRing.position.y=.18;safehouse.add(safeRing);const safeGlow=new THREE.Mesh(new THREE.CylinderGeometry(2.2,2.2,.08,24),new THREE.MeshBasicMaterial({color:0xc7f36b,transparent:true,opacity:.18}));safeGlow.position.y=.03;safehouse.add(safeGlow);safehouse.position.set(0,0,-102);scene.add(safehouse);

const state={started:false,paused:false,inCar:false, cash:250, collected:0, delivered:false, clockMinutes:8*60+30, joyX:0,joyY:0,run:false,jump:false,keys:{},toastTimer:0, cameraYaw:0, cameraPitch:.28};
const ui={cash:document.querySelector('#cash'),title:document.querySelector('#mission-title'),text:document.querySelector('#mission-text'),progress:document.querySelector('#mission-progress'),count:document.querySelector('#mission-count'),mode:document.querySelector('#mode-label'),hint:document.querySelector('#hint-label'),toast:document.querySelector('#toast'),clock:document.querySelector('#clock'),coords:document.querySelector('#coords')};
function toast(message){ui.toast.textContent=message;ui.toast.classList.add('show');clearTimeout(state.toastTimer);state.toastTimer=setTimeout(()=>ui.toast.classList.remove('show'),2400);}
function updateMissionUI(){ui.cash.textContent=`₵ ${state.cash.toLocaleString()}`;ui.progress.style.width=`${state.collected/3*100}%`;ui.count.textContent=state.delivered?'DELIVERED · MISSION COMPLETE':`${state.collected} / 3 DATA DRIVES`;if(state.collected<3){ui.title.textContent='FIRST CONTACT';ui.text.textContent='Find the 3 data drives around the district.';}else if(!state.delivered){ui.title.textContent='SAFEHOUSE DROP';ui.text.textContent='All drives found. Deliver them to the safehouse.';}else{ui.title.textContent='DISTRICT ONE';ui.text.textContent='First contract complete. Explore the city.';}}
updateMissionUI();

const vForward=new THREE.Vector3();
function blocked(x,z,r=.7){for(const c of colliders){if(x+r>c.minX&&x-r<c.maxX&&z+r>c.minZ&&z-r<c.maxZ)return true;}return Math.abs(x)>137||Math.abs(z)>137;}
function attemptMove(obj,dx,dz,r){let nx=obj.position.x+dx,nz=obj.position.z+dz;if(!blocked(nx,obj.position.z,r))obj.position.x=nx;if(!blocked(obj.position.x,nz,r))obj.position.z=nz;}
function near(pos,threshold){const p=state.inCar?car.position:player.position;return Math.hypot(p.x-pos.x,p.z-pos.z)<threshold;}
function getActionHint(){if(state.inCar)return 'Drive through the district · ACT to exit';if(Math.hypot(player.position.x-car.position.x,player.position.z-car.position.z)<4)return 'ACT to enter the car';if(state.collected===3&&!state.delivered&&near(safehouse.position,5))return 'ACT to deliver the data drives';if(drives.some(d=>d.visible&&near(d.position,2.7)))return 'ACT to collect a data drive';return 'Explore District One and find the data drives.';}
function interact(){
 if(state.inCar){state.inCar=false;player.visible=true;player.position.copy(car.position);player.position.x+=Math.sin(car.rotation.y)*2.4;player.position.z+=Math.cos(car.rotation.y)*2.4;player.rotation.y=car.rotation.y;toast('You stepped out of the vehicle.');return;}
 if(Math.hypot(player.position.x-car.position.x,player.position.z-car.position.z)<4){state.inCar=true;player.visible=false;toast('Vehicle acquired. Drive carefully.');return;}
 for(const d of drives){if(d.visible&&near(d.position,2.7)){d.visible=false;state.collected++;state.cash+=50;updateMissionUI();toast(`Data drive secured. +₵50 (${state.collected}/3)`);return;}}
 if(state.collected===3&&!state.delivered&&near(safehouse.position,5)){state.delivered=true;state.cash+=500;updateMissionUI();toast('MISSION COMPLETE · +₵500 · DISTRICT ONE RECOGNISES YOU');return;}
 toast('Nothing to interact with here.');
}
function doJump(){if(state.inCar){state.carBrake=true;return;}state.jumpVelocity=5.4;}

// Touch joystick and action buttons. Pointer Events work for touch, pen and mouse.
const joyZone=document.querySelector('#joystick-zone'),joyKnob=document.querySelector('#joystick-knob');let joyPointer=null;
joyZone.addEventListener('pointerdown',e=>{joyPointer=e.pointerId;joyZone.setPointerCapture(e.pointerId);moveJoy(e);});
joyZone.addEventListener('pointermove',e=>{if(e.pointerId===joyPointer)moveJoy(e);});
function moveJoy(e){const r=joyZone.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const max=34,len=Math.hypot(dx,dy);if(len>max){dx=dx/len*max;dy=dy/len*max;}state.joyX=dx/max;state.joyY=dy/max;joyKnob.style.transform=`translate(${dx}px,${dy}px)`;}
function releaseJoy(e){if(joyPointer===e.pointerId){joyPointer=null;state.joyX=0;state.joyY=0;joyKnob.style.transform='translate(0,0)';}}
joyZone.addEventListener('pointerup',releaseJoy);joyZone.addEventListener('pointercancel',releaseJoy);joyZone.addEventListener('lostpointercapture',()=>{joyPointer=null;state.joyX=0;state.joyY=0;joyKnob.style.transform='translate(0,0)';});
const bindHold=(id,down,up)=>{const el=document.getElementById(id);el.addEventListener('pointerdown',e=>{e.preventDefault();el.setPointerCapture(e.pointerId);down();});const done=()=>up();el.addEventListener('pointerup',done);el.addEventListener('pointercancel',done);};
bindHold('run-btn',()=>state.run=true,()=>state.run=false);bindHold('jump-btn',()=>{state.jump=true;doJump();},()=>state.jump=false);
document.querySelector('#action-btn').addEventListener('click',interact);
window.addEventListener('keydown',e=>{state.keys[e.code]=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();if(e.code==='KeyE'&&!e.repeat)interact();if(e.code==='Escape'&&!e.repeat)togglePause();});
window.addEventListener('keyup',e=>state.keys[e.code]=false);

// Drag the scene to orbit the follow camera on desktop or in the upper part of touch screens.
let lookPointer=null,lastLookX=0,lastLookY=0;
renderer.domElement.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'||e.clientY<innerHeight*.62){lookPointer=e.pointerId;lastLookX=e.clientX;lastLookY=e.clientY;renderer.domElement.setPointerCapture(e.pointerId);}});
renderer.domElement.addEventListener('pointermove',e=>{if(lookPointer!==e.pointerId)return;const dx=e.clientX-lastLookX,dy=e.clientY-lastLookY;lastLookX=e.clientX;lastLookY=e.clientY;state.cameraYaw-=dx*.004;state.cameraPitch=THREE.MathUtils.clamp(state.cameraPitch+dy*.002,-.05,.7);});
renderer.domElement.addEventListener('pointerup',e=>{if(lookPointer===e.pointerId)lookPointer=null;});renderer.domElement.addEventListener('pointercancel',()=>lookPointer=null);

function togglePause(){if(!state.started)return;state.paused=!state.paused;document.querySelector('#pause-overlay').classList.toggle('hidden',!state.paused);}
document.querySelector('#start-btn').addEventListener('click',()=>{state.started=true;document.querySelector('#start-overlay').classList.add('hidden');toast('Welcome to District One. Find three data drives.');});
document.querySelector('#resume-btn').addEventListener('click',togglePause);

const clockCanvas=document.querySelector('#minimap'),ctx=clockCanvas.getContext('2d');
function drawMinimap(){const w=clockCanvas.width,h=clockCanvas.height;ctx.clearRect(0,0,w,h);ctx.fillStyle='#304443';ctx.fillRect(0,0,w,h);const sx=w/280,sz=h/280;ctx.fillStyle='#7d8980';for(let p=-4;p<=4;p++){const px=(p*34+140)*sx,py=(p*34+140)*sz;ctx.fillRect(px-5.5*sx,0,11*sx,h);ctx.fillRect(0,py-5.5*sz,w,11*sz);}ctx.fillStyle='rgba(199,243,107,.22)';ctx.fillRect(w*.35,h*.35,w*.3,h*.3);ctx.fillStyle='#d5d2bf';ctx.fillRect((safehouse.position.x+140)*sx-3,(safehouse.position.z+140)*sz-3,6,6);ctx.fillStyle='#c7f36b';for(const d of drives)if(d.visible){ctx.beginPath();ctx.arc((d.position.x+140)*sx,(d.position.z+140)*sz,3.4,0,Math.PI*2);ctx.fill();}const p=state.inCar?car.position:player.position;ctx.save();ctx.translate((p.x+140)*sx,(p.z+140)*sz);ctx.rotate(-(state.inCar?car.rotation.y:player.rotation.y));ctx.fillStyle='#fff';ctx.beginPath();ctx.moveTo(0,-6);ctx.lineTo(4.5,5);ctx.lineTo(0,3);ctx.lineTo(-4.5,5);ctx.closePath();ctx.fill();ctx.restore();}

let previous=performance.now();
function animate(now){requestAnimationFrame(animate);const dt=Math.min((now-previous)/1000,.04);previous=now;if(!state.started||state.paused){renderer.render(scene,camera);return;}
 state.clockMinutes+=dt*1.5;const hours=Math.floor(state.clockMinutes/60)%24,mins=Math.floor(state.clockMinutes%60);ui.clock.textContent=`${String(hours).padStart(2,'0')}:${String(mins).padStart(2,'0')}`;
 // Keyboard + joystick input, with camera-relative walking.
 let ix=state.joyX,iz=state.joyY;
 if(state.keys.KeyA||state.keys.ArrowLeft)ix-=1;if(state.keys.KeyD||state.keys.ArrowRight)ix+=1;if(state.keys.KeyW||state.keys.ArrowUp)iz-=1;if(state.keys.KeyS||state.keys.ArrowDown)iz+=1;
 const inputLen=Math.hypot(ix,iz);if(inputLen>1){ix/=inputLen;iz/=inputLen;}
 if(state.inCar){
   const throttle=-iz,steer=ix;state.carSpeed??=0;state.carSpeed+=throttle*dt*18;state.carSpeed*=Math.pow(.985,dt*60);state.carSpeed=THREE.MathUtils.clamp(state.carSpeed,-8,23);if(state.jump)state.carSpeed*=Math.pow(.90,dt*60);
   car.rotation.y-=steer*dt*(.75+Math.abs(state.carSpeed)*.045)*Math.sign(state.carSpeed||1);
   const dx=Math.sin(car.rotation.y)*state.carSpeed*dt,dz=Math.cos(car.rotation.y)*state.carSpeed*dt;const old=car.position.clone();attemptMove(car,dx,dz,1.35);if(Math.abs(car.position.x-old.x)+Math.abs(car.position.z-old.z)<.001)state.carSpeed*=-.22;
   ui.mode.textContent='IN VEHICLE';ui.hint.textContent=getActionHint();
 }else{
   const speed=state.run||state.keys.ShiftLeft||state.keys.ShiftRight?8.4:4.4;
   const forward=new THREE.Vector3(Math.sin(state.cameraYaw),0,Math.cos(state.cameraYaw));const right=new THREE.Vector3(forward.z,0,-forward.x);
   const move=right.multiplyScalar(ix).add(forward.multiplyScalar(-iz));
   if(move.lengthSq()>.001){move.normalize();player.rotation.y=Math.atan2(move.x,move.z);attemptMove(player,move.x*speed*dt,move.z*speed*dt,.62);}
   state.jumpVelocity??=0;state.jumpVelocity-=14*dt;player.position.y=Math.max(0,player.position.y+state.jumpVelocity*dt);if(player.position.y===0)state.jumpVelocity=0;
   const walking=move.lengthSq()>.001;const swing=walking?Math.sin(now*.012)*.45:0;legL.rotation.x=swing;legR.rotation.x=-swing;armL.rotation.x=-swing*.7;armR.rotation.x=swing*.7;
   ui.mode.textContent='ON FOOT';ui.hint.textContent=getActionHint();
 }
 for(const d of drives)if(d.visible){d.rotation.y+=dt*.7;d.children[0].rotation.z+=dt*.55;d.position.y=0.12+Math.sin(now*.002+d.userData.index)*.12;}
 safeRing.rotation.z+=dt*.45;safehouse.position.y=.05+Math.sin(now*.0015)*.05;
 pedestrians.forEach((p,i)=>{p.mesh.position.x=p.origin.x+Math.sin(now*.00025+p.phase)*1.5;p.mesh.position.z=p.origin.z+Math.cos(now*.00025+p.phase)*1.5;p.mesh.rotation.y=Math.sin(now*.00025+p.phase)*.5;});
 const target=state.inCar?car.position:player.position;const yaw=state.inCar?car.rotation.y:state.cameraYaw;const distance=state.inCar?11:8.3;const height=state.inCar?5.8:5.2;const desired=new THREE.Vector3(target.x-Math.sin(yaw)*distance, target.y+height+state.cameraPitch*4, target.z-Math.cos(yaw)*distance);camera.position.lerp(desired,1-Math.pow(.001,dt));camera.lookAt(target.x,target.y+1.15,target.z);
 ui.coords.textContent=`SECTOR ${String.fromCharCode(65+Math.max(0,Math.min(7,Math.floor((target.x+140)/35))))}${Math.max(1,Math.min(8,Math.floor((target.z+140)/35)+1))} · ${String(Math.round(target.x)).padStart(3,'0')} / ${String(Math.round(target.z)).padStart(3,'0')}`;
 drawMinimap();renderer.render(scene,camera);
}
requestAnimationFrame(animate);
function resize(){camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,isMobile?1.35:1.8));}
window.addEventListener('resize',resize);
// Pause when the app is backgrounded; avoid a huge simulation step on return.
document.addEventListener('visibilitychange',()=>{if(document.hidden&&state.started&&!state.paused)togglePause();previous=performance.now();});
if('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
