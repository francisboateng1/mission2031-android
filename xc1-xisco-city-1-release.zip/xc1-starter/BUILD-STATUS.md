# XC 1 build status

## Included in this source release

- Six-chapter single-player story campaign and free roam.
- Five city districts with procedural original 3D geometry.
- On-foot movement, camera orbit, jumping, running and a player-driven vehicle.
- Pedestrian routines, traffic loops, a day/night cycle, minimap and HUD.
- Story pickups, hidden collectibles, timed driving challenges and vehicle upgrades.
- Local save data, mission journal, settings and installable PWA metadata.
- Android touch controls designed for landscape play, plus desktop keyboard/mouse controls.

## Checks completed in the preparation environment

- JavaScript syntax validation passed.
- Vite configuration and service-worker syntax validation passed.
- `package.json` and the web-app manifest parse as valid JSON.
- All JavaScript-referenced HTML element IDs were found; no duplicate HTML IDs were found.
- The rightward joystick and vehicle-steering directions use positive screen-right input.

## Checks still required before public launch

The package has not been installed, bundled, or play-tested in a real Android browser in this preparation environment because the npm registry was unreachable here. In the user's GitHub Codespace, run `npm install` and `npm run build`, then complete `QA-CHECKLIST.md` on the actual target phone(s). Fix any runtime, graphics, input, mission-flow, performance, or install issues discovered there before public distribution.

This release is an installable browser game (PWA), not an Android APK. It is a complete small-scope first-edition game project, not a GTA-scale commercial production. The project does not include online multiplayer, cloud accounts/saves, combat, voice acting, licensed music, or destructible environments.
