# XC 1 device test checklist

Run this checklist on the actual Android phones and browsers you intend to support before a public launch.

## Install and first launch

- [ ] Deploy the `dist/` folder to an HTTPS host.
- [ ] Open the live URL in Chrome on Android.
- [ ] Install using Chrome's **Install app** / **Add to Home screen** option.
- [ ] Launch the installed game and rotate to landscape.
- [ ] Confirm the HUD, pause button, minimap and touch controls do not overlap Android system navigation.
- [ ] Launch online, reload once more while still online so the service worker can cache the game bundles, then test a later launch with the network disconnected.

## Movement and camera

- [ ] Push the joystick up: character moves forward.
- [ ] Push the joystick down: character moves backward.
- [ ] Push left: character moves left.
- [ ] Push right: character moves right (not left).
- [ ] Hold RUN while walking: character moves faster.
- [ ] Tap JUMP: character jumps and lands.
- [ ] Drag the world: camera rotates smoothly without moving the character.
- [ ] Test all of the above with the phone held in both hands and with different thumb positions.

## Vehicle

- [ ] Walk to the red starter car and press ACT to enter.
- [ ] Push up to accelerate and down to reverse.
- [ ] Push right: car turns right; push left: car turns left.
- [ ] Hold BOOST to increase acceleration; hold BRAKE to slow down.
- [ ] Drive into buildings and confirm the car is blocked rather than passing through them.
- [ ] Press ACT to exit, then re-enter the vehicle.

## Story and activities

- [ ] Meet Ama at Signal Plaza and complete the first conversation.
- [ ] Recover all three signal fragments and return to Ama.
- [ ] Bring the car to Kweku and complete the Midnight Circuit.
- [ ] Meet Esi, recover the three harbour relays and return to her.
- [ ] Bring the car to Kojo, complete the Blackout Run and restore Relay 07.
- [ ] Return to Ama and complete the story ending.
- [ ] Collect optional City Echoes.
- [ ] Complete a Courier Contract.
- [ ] Visit Meko's Motor Works and test both vehicle upgrades.

## Saving and menus

- [ ] Save at the safehouse and from the pause menu.
- [ ] Close and reopen the game; select Continue and confirm progress is restored.
- [ ] Confirm the mission journal reflects completed chapters.
- [ ] Change graphics, sensitivity and sound settings; reload and confirm they persist.
- [ ] Start a new game and verify the save-overwrite confirmation appears.

## Performance and release blockers

- [ ] Test on a lower-end Android device as well as a newer device.
- [ ] Check for overheating, frame drops, memory reloads and battery drain during a 20-minute session.
- [ ] Test with incoming notifications and app background / foreground transitions.
- [ ] Check touch controls at 320px-wide viewports and short landscape screens.
- [ ] Record any blocked pickups, mission triggers, collision gaps or confusing objectives.
- [ ] Decide whether the first public release needs a native APK, original music, voice acting, combat, cloud saves or additional story content. Those are not included in this build.

A build should not be described as publicly release-tested until these checks have been completed on supported devices.
