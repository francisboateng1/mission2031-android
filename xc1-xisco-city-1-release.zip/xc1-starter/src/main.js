let THREE;
try {
  THREE = await import('three');
} catch (error) {
  const screen = document.getElementById('error-screen');
  if (screen) { screen.classList.remove('hidden'); const message = document.getElementById('error-message'); if (message) message.textContent = 'The 3D engine could not load from the installed packages. Run npm install in this project folder, then reload XC 1.'; }
  throw error;
}

// XC 1 — Xisco City. A self-contained, single-player open-world adventure.
// All 3D art is original procedural geometry. No third-party game assets are used.

const $ = (id) => document.getElementById(id);
const ui = {
  root: $('game-root'), start: $('start-overlay'), pause: $('pause-overlay'), dialog: $('dialog-overlay'),
  journal: $('journal-overlay'), settings: $('settings-overlay'), ending: $('ending-overlay'), error: $('error-screen'),
  startBtn: $('start-btn'), continueBtn: $('continue-btn'), resumeBtn: $('resume-btn'), pauseBtn: $('pause-btn'),
  cash: $('cash'), rep: $('rep'), missionTitle: $('mission-title'), missionText: $('mission-text'),
  missionProgress: $('mission-progress'), missionCount: $('mission-count'), district: $('district-label'),
  clock: $('clock'), timeLabel: $('time-label'), weather: $('weather-label'), weatherIcon: $('weather-icon'),
  coords: $('coords'), mode: $('mode-label'), hint: $('hint-label'), toast: $('toast'),
  activity: $('activity-card'), activityText: $('activity-text'), activityTimer: $('activity-timer'),
  minimap: $('minimap'), dialogKicker: $('dialog-kicker'), dialogTitle: $('dialog-title'), dialogText: $('dialog-text'),
  journalContent: $('journal-content'), endingStats: $('ending-stats'),
};

const isMobile = matchMedia('(max-width: 700px)').matches || ('ontouchstart' in window);
const STORAGE_KEY = 'xc1-save-v1';
const SETTINGS_KEY = 'xc1-settings-v1';
let renderer;
try {
  renderer = new THREE.WebGLRenderer({ antialias: !isMobile, powerPreference: 'high-performance', alpha: false });
} catch (error) {
  ui.error.classList.remove('hidden');
  $('error-message').textContent = 'WebGL could not start on this browser or device. Try the latest Chrome, enable hardware acceleration, and close other graphics-heavy tabs.';
  throw error;
}

const savedSettings = readJSON(SETTINGS_KEY, {});
const settings = {
  quality: ['performance', 'balanced', 'high'].includes(savedSettings.quality) ? savedSettings.quality : 'balanced',
  sensitivity: Number.isFinite(savedSettings.sensitivity) ? THREE.MathUtils.clamp(savedSettings.sensitivity, .5, 1.5) : 1,
  sound: savedSettings.sound !== false,
};
function applyRendererSettings() {
  const ratio = settings.quality === 'high' ? (isMobile ? 1.5 : 2) : settings.quality === 'performance' ? 1 : (isMobile ? 1.2 : 1.6);
  renderer.setPixelRatio(Math.min(devicePixelRatio || 1, ratio));
  renderer.shadowMap.enabled = settings.quality !== 'performance' && !isMobile;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
}
applyRendererSettings();
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.06;
ui.root.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x8aa69f);
scene.fog = new THREE.Fog(0x8aa69f, 125, 360);
const camera = new THREE.PerspectiveCamera(61, innerWidth / innerHeight, .1, 620);
const hemi = new THREE.HemisphereLight(0xdcebe0, 0x39494a, 1.9); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffdfb1, 2.15);
sun.position.set(-85, 120, 55); sun.castShadow = renderer.shadowMap.enabled;
sun.shadow.mapSize.set(1024, 1024); sun.shadow.camera.left = -190; sun.shadow.camera.right = 190;
sun.shadow.camera.top = 190; sun.shadow.camera.bottom = -190; sun.shadow.bias = -.0005; scene.add(sun);

const mat = (color, roughness = .88, metalness = 0, extra = {}) => new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });
const M = {
  grass: mat(0x5b765f), road: mat(0x303b3e), roadEdge: mat(0x66716b), sidewalk: mat(0xb4ae9b),
  line: mat(0xe3c978), white: mat(0xe8e4d8), glass: mat(0x6b9a9a, .3, .22), darkGlass: mat(0x243c43, .25, .25),
  trim: mat(0x384747), tree: mat(0x315d4c), tree2: mat(0x477557), trunk: mat(0x70543a),
  neon: mat(0xc7f36b, .45, .08, { emissive: 0x364c16, emissiveIntensity: .6 }),
  gold: mat(0xe6b856, .48, .16, { emissive: 0x664315, emissiveIntensity: .25 }),
  water: mat(0x236b78, .25, .18),
  buildings: [0xb0a28b, 0x879b94, 0xc7b99f, 0x6e8586, 0x9c8c80, 0x82917f, 0x667b78, 0xc3ae8e].map(c => mat(c)),
};
const colliders = [];
const rand = (a, b) => a + Math.random() * (b - a);
const clamp = THREE.MathUtils.clamp;
const V = (x, z) => new THREE.Vector3(x, 0, z);

function addBox(parent, w, h, d, material, x, y, z, { shadow = false, receive = true } = {}) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), material);
  mesh.position.set(x, y, z); mesh.castShadow = shadow; mesh.receiveShadow = receive; parent.add(mesh); return mesh;
}
function addCollider(x, z, w, d) { colliders.push({ minX: x - w / 2, maxX: x + w / 2, minZ: z - d / 2, maxZ: z + d / 2 }); }
function addTree(x, z, scale = 1) {
  const group = new THREE.Group();
  const trunk = new THREE.Mesh(new THREE.CylinderGeometry(.16 * scale, .23 * scale, 2 * scale, 6), M.trunk);
  trunk.position.y = scale; group.add(trunk);
  for (let i = 0; i < 3; i++) {
    const crown = new THREE.Mesh(new THREE.IcosahedronGeometry((1.0 - i * .12) * scale, 1), i % 2 ? M.tree2 : M.tree);
    crown.position.set(rand(-.3, .3) * scale, (2.0 + i * .35) * scale, rand(-.25, .25) * scale); crown.castShadow = true; group.add(crown);
  }
  group.position.set(x, 0, z); scene.add(group); return group;
}
function makeRoadNetwork() {
  addBox(scene, 370, .15, 370, M.grass, 0, -.19, 0);
  for (let p = -160; p <= 160; p += 40) {
    addBox(scene, 370, .16, 12, M.road, 0, -.025, p);
    addBox(scene, 12, .16, 370, M.road, p, -.025, 0);
    for (const side of [-1, 1]) {
      addBox(scene, 370, .18, 2.4, M.sidewalk, 0, .045, p + side * 7.2);
      addBox(scene, 2.4, .18, 370, M.sidewalk, p + side * 7.2, .045, 0);
    }
    for (let q = -160; q <= 160; q += 40) {
      if (p !== 0) {
        addBox(scene, 2.4, .025, .18, M.line, p, .075, q - 3.1);
        addBox(scene, 2.4, .025, .18, M.line, p, .075, q + 3.1);
      }
      if (q !== 0) {
        addBox(scene, .18, .025, 2.4, M.line, q - 3.1, .075, p);
        addBox(scene, .18, .025, 2.4, M.line, q + 3.1, .075, p);
      }
    }
  }
}
makeRoadNetwork();

function districtFor(x, z) {
  if (x < -45 && z < -40) return 'OLD QUARTER';
  if (x > 45 && z > 40) return 'THE HARBOUR';
  if (x < -45 && z > 40) return 'INNOVATION PARK';
  if (x > 45 && z < -40) return 'HIGHLAND ESTATES';
  return 'CENTRAL CITY';
}
function makeBuilding(x, z, w, d, h, colorIndex, style) {
  const group = new THREE.Group();
  const bodyColor = [0xb0a28b, 0x879b94, 0xc7b99f, 0x6e8586, 0x9c8c80, 0x82917f, 0x667b78, 0xc3ae8e][colorIndex % 8];
  const facadeCanvas = document.createElement('canvas'); facadeCanvas.width = 256; facadeCanvas.height = 256;
  const fctx = facadeCanvas.getContext('2d');
  fctx.fillStyle = `#${bodyColor.toString(16).padStart(6, '0')}`; fctx.fillRect(0, 0, 256, 256);
  const floors = Math.max(2, Math.min(8, Math.floor(h / 3.1)));
  const cols = Math.max(3, Math.floor(w / 2.9));
  fctx.fillStyle = style === 'old' ? '#355b57' : '#2b5157';
  for (let row = 0; row < floors; row++) for (let col = 0; col < cols; col++) {
    const cellW = 256 / cols, cellH = 256 / floors;
    const wx = col * cellW + cellW * .22, wy = row * cellH + cellH * .2;
    fctx.fillRect(wx, wy, cellW * .56, cellH * .54);
    fctx.fillStyle = 'rgba(222,228,208,.32)'; fctx.fillRect(wx - 2, wy + cellH * .54, cellW * .6, 3);
    fctx.fillStyle = style === 'old' ? '#355b57' : '#2b5157';
  }
  fctx.fillStyle = 'rgba(255,255,255,.12)';
  for (let row = 0; row < floors; row++) fctx.fillRect(0, row * 256 / floors, 256, 2);
  const facadeTexture = new THREE.CanvasTexture(facadeCanvas); facadeTexture.colorSpace = THREE.SRGBColorSpace;
  const facadeMaterial = new THREE.MeshStandardMaterial({ map: facadeTexture, roughness: .82, metalness: style === 'glass' ? .12 : 0 });
  addBox(group, w, h, d, facadeMaterial, 0, h / 2, 0, { shadow: true });
  addBox(group, w + .55, .35, d + .55, M.trim, 0, h + .16, 0);
  if (style === 'glass') addBox(group, w + .22, .16, d + .22, M.glass, 0, h * .68, 0);
  const signMaterial = colorIndex % 3 === 0 ? M.neon : M.gold;
  addBox(group, Math.min(w * .52, 5.2), .62, .13, signMaterial, 0, 1.08, -d / 2 - .1);
  if (h > 24) {
    addBox(group, w * .24, 1.1, d * .25, M.darkGlass, w * .18, h + .86, d * .1);
    const antenna = new THREE.Mesh(new THREE.CylinderGeometry(.07, .12, 3.4, 6), M.trim); antenna.position.set(-w * .2, h + 1.8, 0); group.add(antenna);
  }
  group.position.set(x, 0, z); scene.add(group); addCollider(x, z, w + 1.1, d + 1.1);
  return group;
}

function makeCity() {
  let index = 0;
  for (let x = -140; x <= 140; x += 40) {
    for (let z = -140; z <= 140; z += 40) {
      // Keep key public spaces clear and recognisable.
      if ((Math.abs(x) < 24 && Math.abs(z) < 24) || (x === -100 && z === -100) || (x === 100 && z === 100) || (x === -100 && z === 100)) continue;
      const district = districtFor(x, z);
      const style = district === 'OLD QUARTER' ? 'old' : district === 'INNOVATION PARK' ? 'glass' : 'modern';
      let h = rand(9, 19);
      if (district === 'CENTRAL CITY') h = rand(20, 42);
      if (district === 'OLD QUARTER') h = rand(7, 14);
      if (district === 'THE HARBOUR') h = rand(8, 15);
      if (district === 'HIGHLAND ESTATES') h = rand(8, 18);
      if (district === 'INNOVATION PARK') h = rand(15, 31);
      const w = rand(15, 19), d = rand(15, 19);
      makeBuilding(x + rand(-1.5, 1.5), z + rand(-1.5, 1.5), w, d, h, index++, style);
      // Trees and street furniture live on selected corners, never in the driving lanes.
      if ((index % 4) === 0) addTree(x + 14, z + 13, rand(.75, 1.05));
      if ((index % 7) === 0) addTree(x - 14, z - 13, rand(.7, .95));
    }
  }
  // Signal Plaza.
  addBox(scene, 25, .2, 25, mat(0x909d8d), 0, .02, 0);
  for (const [x, z] of [[-10, -9], [10, -9], [-10, 9], [10, 9]]) addTree(x, z, .9);
  addBox(scene, 12, 5.5, .7, M.trim, 0, 3, -14, { shadow: true });
  addBox(scene, 10.8, 3.3, .12, M.neon, 0, 3.1, -14.42);
  addSign('XISCO CITY', 'SIGNAL PLAZA', 0, 3.1, -14.52, 10.5, 3.1);
  // Old Quarter gateway and market awnings.
  addBox(scene, 15, 6, .8, mat(0xb58a5d), -100, 3, -60, { shadow: true });
  addBox(scene, 12, .35, .9, mat(0x573c2f), -100, 6.2, -60);
  addSign('OLD QUARTER', 'MARKET & HERITAGE', -100, 3, -60.5, 13, 2.4, '#fff0d2', '#815238');
  for (let i = 0; i < 4; i++) {
    const awning = addBox(scene, 4.2, .25, 3.1, mat([0xc96b49, 0xe0b75f, 0x4f8c87, 0xb6535f][i]), -114 + i * 9, 2.6, -86);
  }
  // Innovation Park glass campus.
  addBox(scene, 23, .4, 19, mat(0x859c91), -100, .1, 100);
  addBox(scene, 12, 26, 12, mat(0x577d7d, .25, .18), -100, 13, 100, { shadow: true });
  addSign('XISCO LABS', 'INNOVATION PARK', -100, 7, 93.75, 10, 4);
  addCollider(-100, 100, 13, 13);
  // Highland Estates: a private garden and a distinctive villa.
  addBox(scene, 26, .15, 22, mat(0x849b77), 100, .04, -100);
  addBox(scene, 17, 9, 15, mat(0xc7b99d), 100, 4.5, -100, { shadow: true });
  addBox(scene, 18, .55, 16, mat(0x5a4a3d), 100, 9.3, -100);
  addCollider(100, -100, 18, 16);
  addSign('HIGHLAND', 'ESTATES', 100, 4.3, -107.6, 9, 2.5);
  // Harbour water, pier, containers and crane.
  addBox(scene, 74, .4, 118, M.water, 191, -.12, 88);
  addBox(scene, 65, .5, 22, mat(0x777c72), 137, .02, 88);
  addBox(scene, 52, .42, 9, mat(0x8f8574), 135, .14, 110);
  for (let i = 0; i < 8; i++) {
    const c = mat([0xb45d43, 0x4c777a, 0xc6a354, 0x6a7d6c][i % 4]);
    const cx = 117 + (i % 4) * 12, cz = 75 + Math.floor(i / 4) * 18;
    addBox(scene, 9.5, 5.5, 8, c, cx, 2.8, cz, { shadow: true });
  }
  addBox(scene, 1.2, 22, 1.2, mat(0x4d5450), 153, 11, 75);
  const boom = addBox(scene, 22, .8, 1.2, mat(0x4d5450), 144, 21, 75); boom.rotation.z = -.12;
  addBox(scene, .45, 13, .45, mat(0x4d5450), 136, 14.5, 75);
  addSign('THE HARBOUR', 'PORT & LOGISTICS', 133, 5, 68.7, 13, 2.6);
  // Relay tower on the northwest ridge.
  addBox(scene, 24, .5, 24, mat(0x6d817a), -120, .12, -120);
  addBox(scene, 5, 27, 5, mat(0x52656a), -120, 13.5, -120, { shadow: true });
  for (let y = 8; y <= 25; y += 5) {
    const ring = new THREE.Mesh(new THREE.TorusGeometry(4.2, .16, 6, 20), M.gold); ring.rotation.x = Math.PI / 2; ring.position.set(-120, y, -120); scene.add(ring);
  }
  const beacon = new THREE.Mesh(new THREE.CylinderGeometry(.28, .4, 6, 8), new THREE.MeshBasicMaterial({ color: 0xc7f36b })); beacon.position.set(-120, 29, -120); scene.add(beacon);
  addSign('RELAY 07', 'CITY NETWORK', -120, 7, -122.7, 9, 2.3);
  // Lamp posts on major junctions.
  for (let p = -120; p <= 120; p += 80) for (const side of [-1, 1]) {
    const post = new THREE.Mesh(new THREE.CylinderGeometry(.07, .1, 5.5, 6), M.trim); post.position.set(p + side * 10, 2.75, 10); scene.add(post);
    const lamp = new THREE.Mesh(new THREE.SphereGeometry(.2, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffe4a3 })); lamp.position.set(p + side * 10, 5.35, 10); scene.add(lamp);
  }
}
function addSign(line1, line2, x, y, z, w, h, fg = '#142017', bg = '#c7f36b') {
  const canvas = document.createElement('canvas'); canvas.width = 768; canvas.height = 256;
  const ctx = canvas.getContext('2d'); ctx.fillStyle = bg; ctx.fillRect(0, 0, 768, 256);
  ctx.fillStyle = fg; ctx.textAlign = 'center'; ctx.font = '900 78px Arial'; ctx.fillText(line1, 384, 102);
  ctx.font = '700 35px Arial'; ctx.fillText(line2, 384, 174);
  const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace;
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: texture, toneMapped: false }));
  mesh.position.set(x, y, z); scene.add(mesh); return mesh;
}
makeCity();

// Original low-poly player and vehicle models.
function makePlayer() {
  const group = new THREE.Group();
  const skin = mat(0x986548), top = mat(0x1f4a45), pants = mat(0x242f37), shoes = mat(0xd9d9ce), hair = mat(0x171d1b);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(.46, .78, 4, 8), top); torso.position.y = 1.42; torso.castShadow = true; group.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(.32, 12, 10), skin); head.position.y = 2.26; head.castShadow = true; group.add(head);
  const cap = new THREE.Mesh(new THREE.SphereGeometry(.34, 12, 8, 0, Math.PI * 2, 0, Math.PI * .48), hair); cap.position.set(0, 2.4, 0); group.add(cap);
  const leftArm = new THREE.Group(); leftArm.position.set(-.55, 1.77, 0); group.add(leftArm);
  const arm1 = new THREE.Mesh(new THREE.CapsuleGeometry(.13, .58, 3, 6), top); arm1.position.y = -.3; leftArm.add(arm1);
  const rightArm = leftArm.clone(); rightArm.position.x = .55; group.add(rightArm);
  const leftLeg = new THREE.Group(); leftLeg.position.set(-.21, .85, 0); group.add(leftLeg);
  const leg1 = new THREE.Mesh(new THREE.CapsuleGeometry(.16, .64, 3, 6), pants); leg1.position.y = -.34; leftLeg.add(leg1);
  const rightLeg = leftLeg.clone(); rightLeg.position.x = .21; group.add(rightLeg);
  for (const x of [-.21, .21]) addBox(group, .32, .16, .54, shoes, x, .13, .08);
  return { group, parts: { leftArm, rightArm, leftLeg, rightLeg } };
}
function makeCar(color = 0x9a332b, scale = 1) {
  const group = new THREE.Group();
  const paint = mat(color, .36, .24), rubber = mat(0x111719), hubMat = mat(0xc5c8bc, .45, .4);
  addBox(group, 2.28 * scale, .72 * scale, 4.45 * scale, paint, 0, .73 * scale, 0, { shadow: true });
  addBox(group, 1.75 * scale, .92 * scale, 2.3 * scale, M.darkGlass, 0, 1.48 * scale, -.18 * scale);
  addBox(group, 1.84 * scale, .13 * scale, 2.34 * scale, paint, 0, 1.98 * scale, -.18 * scale);
  addBox(group, .34 * scale, .5 * scale, .12 * scale, paint, -1.1 * scale, 1.13 * scale, .15 * scale);
  addBox(group, .34 * scale, .5 * scale, .12 * scale, paint, 1.1 * scale, 1.13 * scale, .15 * scale);
  const wheels = [];
  for (const x of [-1.12, 1.12]) for (const z of [-1.42, 1.42]) {
    const pivot = new THREE.Group(); pivot.position.set(x * scale, .48 * scale, z * scale); group.add(pivot);
    const wheel = new THREE.Mesh(new THREE.CylinderGeometry(.43 * scale, .43 * scale, .26 * scale, 12), rubber); wheel.rotation.z = Math.PI / 2; pivot.add(wheel);
    const hub = new THREE.Mesh(new THREE.CylinderGeometry(.19 * scale, .19 * scale, .28 * scale, 10), hubMat); hub.rotation.z = Math.PI / 2; pivot.add(hub); wheels.push(pivot);
  }
  for (const x of [-.76, .76]) {
    addBox(group, .48 * scale, .2 * scale, .08 * scale, M.white, x * scale, .77 * scale, 2.26 * scale);
    addBox(group, .42 * scale, .2 * scale, .08 * scale, mat(0xc53d32), x * scale, .77 * scale, -2.26 * scale);
  }
  addBox(group, .18 * scale, .12 * scale, .22 * scale, M.trim, -1.18 * scale, .95 * scale, .35 * scale);
  addBox(group, .18 * scale, .12 * scale, .22 * scale, M.trim, 1.18 * scale, .95 * scale, .35 * scale);
  return { group, wheels };
}
const playerModel = makePlayer();
const player = playerModel.group; player.position.set(0, 0, 6); scene.add(player);
const carModel = makeCar();
const car = carModel.group; car.position.set(7, 0, -7); car.rotation.y = 0; scene.add(car);

function makeNPC(name, x, z, color, accent = 0x1a1c1a) {
  const group = new THREE.Group();
  const bodyMat = mat(color), skin = mat(0x986548), dark = mat(accent);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(.31, .58, 3, 7), bodyMat); torso.position.y = 1.08; group.add(torso);
  const head = new THREE.Mesh(new THREE.SphereGeometry(.22, 10, 8), skin); head.position.y = 1.76; group.add(head);
  const hair = new THREE.Mesh(new THREE.SphereGeometry(.23, 9, 7, 0, Math.PI * 2, 0, Math.PI * .5), dark); hair.position.y = 1.88; group.add(hair);
  group.position.set(x, 0, z); scene.add(group);
  return { name, group, position: V(x, z) };
}
const NPC = {
  ama: makeNPC('AMA', 4, 11, 0x8d563b, 0x201b19),
  kweku: makeNPC('KWEKU', -47, -40, 0x4d6f91, 0x202020),
  esi: makeNPC('ESI', 130, 103, 0x9c6b3c, 0x242020),
  kojo: makeNPC('KOJO', -112, 78, 0x577c68, 0x181f1b),
  courier: makeNPC('TARIQ', 40, -47, 0x9c7948, 0x25201c),
  mechanic: makeNPC('MEKO', 42, 105, 0x596a9b, 0x222020),
};
function makeNPCLabel(npc, label) {
  const canvas = document.createElement('canvas'); canvas.width = 256; canvas.height = 64;
  const ctx = canvas.getContext('2d'); ctx.fillStyle = 'rgba(7,17,21,.88)'; ctx.fillRect(0, 0, 256, 64);
  ctx.fillStyle = '#c7f36b'; ctx.font = '800 30px Arial'; ctx.textAlign = 'center'; ctx.fillText(label, 128, 42);
  const texture = new THREE.CanvasTexture(canvas); const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false }));
  sprite.position.set(0, 2.55, 0); sprite.scale.set(3.8, .95, 1); npc.group.add(sprite);
}
Object.values(NPC).forEach(npc => makeNPCLabel(npc, npc.name));

// Pedestrian routines: small patrol routes make the streets feel inhabited.
const pedestrians = [];
const pedestrianColors = [0x3d6970, 0xa16d47, 0x747d5e, 0x6b597e, 0xc08054, 0x476a59];
for (let i = 0; i < 19; i++) {
  const alongVertical = Math.random() > .5;
  const roadLine = Math.round(rand(-3, 3)) * 40;
  const side = Math.random() > .5 ? 7.6 : -7.6;
  const startX = alongVertical ? roadLine + side : rand(-145, 145);
  const startZ = alongVertical ? rand(-145, 145) : roadLine + side;
  const npc = makeNPC('CITIZEN', startX, startZ, pedestrianColors[i % pedestrianColors.length], 0x1c201c);
  const route = alongVertical
    ? [V(startX, startZ), V(startX, clamp(startZ + rand(-20, 20), -150, 150)), V(startX, clamp(startZ + rand(-25, 25), -150, 150))]
    : [V(startX, startZ), V(clamp(startX + rand(-20, 20), -150, 150), startZ), V(clamp(startX + rand(-25, 25), -150, 150), startZ)];
  pedestrians.push({ npc, route, routeIndex: 1, speed: rand(.55, 1.05), phase: rand(0, 6) });
}

// Ambient traffic runs on fixed road loops. Cars do not damage the player.
const traffic = [];
const trafficPaths = [
  [[-160, -4], [160, -4], [160, 4], [-160, 4]],
  [[-4, -160], [-4, 160], [4, 160], [4, -160]],
  [[-120, -124], [120, -124], [124, -116], [-116, -116]],
  [[-116, 84], [116, 84], [116, 76], [-116, 76]],
];
for (let i = 0; i < 8; i++) {
  const model = makeCar([0x527f7d, 0xc29a53, 0x6e7788, 0x7c4038, 0xd5d0c3][i % 5], .72);
  const path = trafficPaths[i % trafficPaths.length];
  const pathIndex = i % path.length;
  model.group.position.set(path[pathIndex][0], 0, path[pathIndex][1]);
  model.group.rotation.y = 0; scene.add(model.group);
  traffic.push({ model, path, pathIndex, speed: 5 + (i % 3) * 1.5 });
}

function makeMarker(label, color = 0xc7f36b) {
  const group = new THREE.Group();
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(.12, .32, 4.4, 8), new THREE.MeshBasicMaterial({ color, transparent: true, opacity: .24 })); beam.position.y = 2.2; group.add(beam);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(1.45, .13, 8, 24), new THREE.MeshBasicMaterial({ color })); ring.rotation.x = Math.PI / 2; ring.position.y = .24; group.add(ring);
  const canvas = document.createElement('canvas'); canvas.width = 384; canvas.height = 96;
  const ctx = canvas.getContext('2d'); ctx.fillStyle = 'rgba(5,15,19,.88)'; ctx.fillRect(0, 0, 384, 96); ctx.fillStyle = '#fff'; ctx.font = '900 42px Arial'; ctx.textAlign = 'center'; ctx.fillText(label, 192, 64);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(canvas), transparent: true, depthWrite: false })); sprite.position.y = 5.3; sprite.scale.set(6.2, 1.55, 1); group.add(sprite);
  scene.add(group); return group;
}
const targetMarker = makeMarker('OBJECTIVE');
const objectiveMarkerActive = true;

function makePickup(id, x, z, label, color = 0xc7f36b, type = 'shard') {
  const group = new THREE.Group();
  const coreMat = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: .5, metalness: .35, roughness: .3 });
  if (type === 'relay') {
    const core = new THREE.Mesh(new THREE.OctahedronGeometry(.72, 0), coreMat); core.position.y = .8; group.add(core);
    const hoop = new THREE.Mesh(new THREE.TorusGeometry(1.1, .08, 8, 20), coreMat); hoop.position.y = .8; group.add(hoop);
  } else {
    const core = new THREE.Mesh(new THREE.OctahedronGeometry(.58, 0), coreMat); core.position.y = .72; group.add(core);
    const hoop = new THREE.Mesh(new THREE.TorusGeometry(.86, .07, 8, 20), coreMat); hoop.rotation.x = Math.PI / 2; hoop.position.y = .72; group.add(hoop);
  }
  const labelCanvas = document.createElement('canvas'); labelCanvas.width = 256; labelCanvas.height = 64;
  const lctx = labelCanvas.getContext('2d'); lctx.fillStyle = 'rgba(5,15,19,.8)'; lctx.fillRect(0, 0, 256, 64); lctx.fillStyle = '#fff'; lctx.textAlign = 'center'; lctx.font = '800 28px Arial'; lctx.fillText(label, 128, 42);
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(labelCanvas), transparent: true, depthWrite: false })); sprite.position.y = 2.4; sprite.scale.set(3.6, .9, 1); group.add(sprite);
  group.position.set(x, 0, z); scene.add(group);
  return { id, group, position: V(x, z), baseY: 0, visible: true, type };
}
const signalFragments = [
  makePickup('fragment-a', -45.8, -58, 'SIGNAL 01', 0x8be4d3, 'shard'),
  makePickup('fragment-b', 45.8, -58, 'SIGNAL 02', 0x8be4d3, 'shard'),
  makePickup('fragment-c', -45.8, 58, 'SIGNAL 03', 0x8be4d3, 'shard'),
];
const harbourRelays = [
  makePickup('relay-a', 110, 103, 'RELAY A', 0xf4c777, 'relay'),
  makePickup('relay-b', 153, 120, 'RELAY B', 0xf4c777, 'relay'),
  makePickup('relay-c', 73, 128, 'RELAY C', 0xf4c777, 'relay'),
];
const cityEchoes = [
  [-87, -60], [-87, 27], [-20, -87], [74, 100], [154, -20], [-154, 120], [20, 154], [100, -154], [74, 20], [-20, 74],
].map((p, i) => makePickup(`echo-${i}`, p[0], p[1], 'CITY ECHO', 0xe7ad59, 'echo'));
const safehouse = V(0, -24);

// Story data and persistent player profile.
const chapterNames = [
  'FIRST CONTACT', 'THE GHOST SIGNAL', 'THE MIDNIGHT CIRCUIT',
  'ECHOES AT THE HARBOUR', 'THE BLACKOUT RUN', 'A NEW SIGNAL',
];
const chapterDescriptions = [
  'Find Ama at Signal Plaza.',
  'Recover three signal fragments, then return to Ama.',
  'Bring your car to Kweku in the Old Quarter and prove yourself in the midnight circuit.',
  'Find Esi at the harbour and recover the missing relay components.',
  'Bring your car to Kojo and race the city network back online.',
  'Return to Ama at Signal Plaza.',
];
function defaultProfile() {
  return { mission: 0, phase: 0, cash: 350, rep: 0, fragments: [], relays: [], echoes: [],
    engineUpgrade: false, handlingUpgrade: false, player: [0, 0, 6], car: [7, 0, -7, 0],
    playSeconds: 0, courierWins: 0, completed: false };
}
function readJSON(key, fallback) { try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; } }
function loadProfile() {
  const p = readJSON(STORAGE_KEY, null); if (!p || typeof p !== 'object') return null;
  const fresh = defaultProfile();
  for (const k of Object.keys(fresh)) if (p[k] !== undefined) fresh[k] = p[k];
  fresh.mission = clamp(Number(fresh.mission) || 0, 0, 6); fresh.phase = clamp(Number(fresh.phase) || 0, 0, 3);
  fresh.cash = Math.max(0, Number(fresh.cash) || 0); fresh.rep = Math.max(0, Number(fresh.rep) || 0);
  fresh.fragments = Array.isArray(fresh.fragments) ? fresh.fragments : [];
  fresh.relays = Array.isArray(fresh.relays) ? fresh.relays : [];
  fresh.echoes = Array.isArray(fresh.echoes) ? fresh.echoes : [];
  return fresh;
}
let profile = loadProfile() || defaultProfile();
let hasSave = !!loadProfile();
let activeChallenge = null;
let state = {
  started: false, paused: false, inCar: false, cameraYaw: 0, cameraPitch: .13,
  joyX: 0, joyY: 0, sprint: false, boost: false, brake: false, jumpVelocity: 0,
  keys: Object.create(null), carSpeed: 0, clockMinutes: 9 * 60 + 15, elapsed: 0,
  dialogCallback: null, soundOn: settings.sound, toastUntil: 0, cameraDragging: false,
};
let dialogOpen = false;
let lastSavedAt = 0;
let audioContext = null;

function showToast(message, duration = 2300) {
  ui.toast.textContent = message; ui.toast.classList.add('show'); state.toastUntil = performance.now() + duration;
}
function sound(type = 'tap') {
  if (!state.soundOn) return;
  try {
    audioContext ||= new (window.AudioContext || window.webkitAudioContext)();
    if (audioContext.state === 'suspended') audioContext.resume();
    const osc = audioContext.createOscillator(), gain = audioContext.createGain();
    const now = audioContext.currentTime;
    const tones = { tap: [520, .07], pickup: [720, .15], complete: [880, .28], fail: [160, .18], engine: [240, .09] };
    const [frequency, duration] = tones[type] || tones.tap;
    osc.type = type === 'fail' ? 'sawtooth' : 'sine'; osc.frequency.setValueAtTime(frequency, now);
    if (type === 'complete') osc.frequency.exponentialRampToValueAtTime(1320, now + duration);
    gain.gain.setValueAtTime(.0001, now); gain.gain.exponentialRampToValueAtTime(.09, now + .015); gain.gain.exponentialRampToValueAtTime(.0001, now + duration);
    osc.connect(gain); gain.connect(audioContext.destination); osc.start(now); osc.stop(now + duration + .02);
  } catch { /* Audio is optional; gameplay continues silently. */ }
}
function saveGame(quiet = false) {
  const payload = {
    ...profile,
    player: [player.position.x, player.position.y, player.position.z],
    car: [car.position.x, car.position.y, car.position.z, car.rotation.y],
    playSeconds: profile.playSeconds + state.elapsed,
  };
  // Do not save a mid-race timer: an interrupted challenge can be restarted from its contact.
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    profile.playSeconds = payload.playSeconds; state.elapsed = 0; hasSave = true; lastSavedAt = performance.now();
    if (!quiet) showToast('Progress saved in this device.');
    updateMenuButtons();
    return true;
  } catch {
    if (!quiet) showToast('Could not save. Device storage may be full.');
    return false;
  }
}
function updateMenuButtons() { ui.continueBtn.classList.toggle('hidden', !hasSave); }
function applyProfileToWorld() {
  player.position.set(...profile.player);
  car.position.set(profile.car[0], profile.car[1], profile.car[2]); car.rotation.y = profile.car[3] || 0;
  for (const item of signalFragments) { item.visible = !profile.fragments.includes(item.id); item.group.visible = item.visible; }
  for (const item of harbourRelays) { item.visible = !profile.relays.includes(item.id); item.group.visible = item.visible; }
  for (const item of cityEchoes) { item.visible = !profile.echoes.includes(item.id); item.group.visible = item.visible; }
  activeChallenge = null; state.carSpeed = 0; state.inCar = false; player.visible = true;
}
function newGame() {
  if (hasSave && !window.confirm('Start a new XC 1 journey? This will replace the saved story on this device.')) return;
  profile = defaultProfile(); activeChallenge = null; state.cameraYaw = 0; state.cameraPitch = .13; state.clockMinutes = 9 * 60 + 15; state.elapsed = 0; state.jumpVelocity = 0;
  state.keys = Object.create(null); state.sprint = state.boost = state.brake = false; applyProfileToWorld(); saveGame(true); beginGame();
  showToast('Welcome to Xisco City. Find Ama at Signal Plaza.');
}
function continueGame() {
  const loaded = loadProfile(); if (loaded) profile = loaded;
  state.elapsed = 0; state.keys = Object.create(null); state.sprint = state.boost = state.brake = false;
  applyProfileToWorld(); beginGame(); showToast('Journey resumed. The city remembers.');
}
function beginGame() {
  state.started = true; state.paused = false; ui.start.classList.add('hidden'); ui.pause.classList.add('hidden');
  ui.dialog.classList.add('hidden'); ui.ending.classList.add('hidden'); dialogOpen = false;
  updateHUD(); sound('tap');
}
function pauseGame() {
  if (!state.started || dialogOpen) return;
  state.paused = true; ui.pause.classList.remove('hidden');
}
function resumeGame() { state.paused = false; ui.pause.classList.add('hidden'); }
function openDialog(title, text, kicker, callback) {
  ui.dialogTitle.textContent = title; ui.dialogText.textContent = text; ui.dialogKicker.textContent = kicker || 'CITY CONTACT';
  state.dialogCallback = callback || null; dialogOpen = true; ui.dialog.classList.remove('hidden'); sound('tap');
}
function closeDialog() {
  ui.dialog.classList.add('hidden'); dialogOpen = false;
  const callback = state.dialogCallback; state.dialogCallback = null; if (callback) callback();
}

function missionTitle() { return profile.mission >= 6 ? 'FREE ROAM' : chapterNames[profile.mission]; }
function missionObjective() {
  const m = profile.mission, p = profile.phase;
  if (m === 0) return 'Find Ama at Signal Plaza and ask about the strange transmissions.';
  if (m === 1) return p === 0 ? `Collect the signal fragments (${profile.fragments.length}/3).` : 'Return to Ama at Signal Plaza.';
  if (m === 2) return p === 0 ? 'Drive your car to Kweku in the Old Quarter.' : p === 1 ? activeChallenge ? (!state.inCar ? 'Get into your car to begin the midnight circuit.' : `Clear the midnight circuit. Checkpoint ${activeChallenge.index + 1} of ${activeChallenge.points.length}.`) : 'Talk to Kweku to restart the midnight circuit.' : 'Return to Kweku in the Old Quarter.';
  if (m === 3) return p === 0 ? 'Reach the harbour and speak with Esi.' : p === 1 ? `Recover the harbour relay components (${profile.relays.length}/3).` : 'Return to Esi at the harbour.';
  if (m === 4) return p === 0 ? 'Drive your car to Kojo at Innovation Park.' : p === 1 ? activeChallenge ? (!state.inCar ? 'Get into your car to begin the blackout run.' : `Race the blackout route. Checkpoint ${activeChallenge.index + 1} of ${activeChallenge.points.length}.`) : 'Talk to Kojo to restart the blackout run.' : 'Reach Relay 07 and restore the city network.';
  if (m === 5) return 'Return to Ama at Signal Plaza.';
  return 'The story is complete. Explore, discover, race and make the city yours.';
}
function reputationLabel() { return profile.rep >= 180 ? 'CITY ICON' : profile.rep >= 100 ? 'RISING STAR' : profile.rep >= 35 ? 'KNOWN FACE' : 'ROOKIE'; }
function updateHUD() {
  ui.cash.textContent = `₵ ${Math.floor(profile.cash).toLocaleString('en')}`;
  ui.rep.textContent = reputationLabel();
  ui.missionTitle.textContent = missionTitle(); ui.missionText.textContent = missionObjective();
  ui.missionCount.textContent = profile.mission >= 6 ? 'STORY COMPLETE · FREE ROAM' : `CHAPTER ${profile.mission + 1} OF 6 · THE SIGNAL`; 
  const pct = profile.mission >= 6 ? 100 : profile.mission === 1 ? profile.fragments.length / 3 * (profile.phase === 1 ? 70 : 60) : profile.mission === 3 ? profile.relays.length / 3 * (profile.phase === 2 ? 80 : 65) : activeChallenge ? activeChallenge.index / activeChallenge.points.length * 75 : profile.phase ? 60 : 12;
  ui.missionProgress.style.width = `${clamp(pct, 0, 100)}%`;
  ui.activity.classList.toggle('hidden', !activeChallenge);
  if (activeChallenge) {
    ui.activityText.textContent = `${activeChallenge.label} · ${activeChallenge.index + 1}/${activeChallenge.points.length}`;
    ui.activityTimer.textContent = formatTime(activeChallenge.remaining);
  }
}
function formatTime(seconds) { const s = Math.max(0, Math.ceil(seconds)); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; }

function nearestTarget() {
  const m = profile.mission, p = profile.phase;
  if (m === 0 || m === 5) return NPC.ama.position;
  if (m === 1) {
    if (p === 1) return NPC.ama.position;
    const item = signalFragments.find(o => o.visible); return item?.position || NPC.ama.position;
  }
  if (m === 2) {
    if (p === 0 || (p === 1 && !activeChallenge) || p === 2) return NPC.kweku.position;
    return activeChallenge?.points[activeChallenge.index] || NPC.kweku.position;
  }
  if (m === 3) {
    if (p === 0 || p === 2) return NPC.esi.position;
    const item = harbourRelays.find(o => o.visible); return item?.position || NPC.esi.position;
  }
  if (m === 4) {
    if (p === 0 || (p === 1 && !activeChallenge)) return NPC.kojo.position;
    if (p === 1) return activeChallenge?.points[activeChallenge.index] || V(-120, -120);
    return V(-120, -120);
  }
  const echo = cityEchoes.find(o => o.visible); return echo?.position || safehouse;
}
function distanceTo(a, b) { return Math.hypot(a.x - b.x, a.z - b.z); }
function currentPosition() { return state.inCar ? car.position : player.position; }
function near(pos, radius = 4) { return distanceTo(currentPosition(), pos) <= radius; }
function isBlocked(x, z, radius) {
  if (x < -176 + radius || x > 176 - radius || z < -176 + radius || z > 176 - radius) return true;
  if (x > 154 && z > 24 && z < 155) return true; // harbour water boundary
  return colliders.some(c => x + radius > c.minX && x - radius < c.maxX && z + radius > c.minZ && z - radius < c.maxZ);
}
function moveWithCollision(obj, dx, dz, radius) {
  const ox = obj.position.x, oz = obj.position.z;
  if (!isBlocked(ox + dx, oz, radius)) obj.position.x = ox + dx;
  if (!isBlocked(obj.position.x, oz + dz, radius)) obj.position.z = oz + dz;
  return Math.hypot(obj.position.x - ox, obj.position.z - oz);
}
function findNearbyPickup(list, radius = 3.5) { return list.find(item => item.visible && near(item.position, radius)); }
function nearbyNPC() { return Object.values(NPC).find(npc => near(npc.position, 4.2)); }
function getHint() {
  if (dialogOpen) return 'Read the message and continue.';
  if (activeChallenge && !state.inCar) return 'Get into your car to start the timed route';
  if (state.inCar) return 'ACT to exit · RUN to boost · JUMP to brake';
  if (near(car.position, 4.2)) return 'ACT to enter your car';
  const fragment = profile.mission === 1 && profile.phase === 0 ? findNearbyPickup(signalFragments, 3.2) : null; if (fragment) return 'ACT to recover the signal fragment';
  const relay = profile.mission === 3 && profile.phase === 1 ? findNearbyPickup(harbourRelays, 3.2) : null; if (relay) return 'ACT to recover the harbour relay';
  const echo = findNearbyPickup(cityEchoes, 3.2); if (echo) return 'ACT to collect a hidden city echo';
  const npc = nearbyNPC(); if (npc) return `ACT to speak with ${npc.name}`;
  if (near(safehouse, 5)) return 'ACT to save your progress at the safehouse';
  if (near(V(42, 105), 7)) return 'ACT to tune your vehicle at the garage';
  return 'Explore the city and follow the active objective.';
}

function updateDistrict() { ui.district.textContent = districtFor(currentPosition().x, currentPosition().z); }
function completeMissionReward(cash, rep, message) {
  profile.cash += cash; profile.rep += rep; updateHUD(); saveGame(true); sound('complete'); showToast(`${message}  +₵${cash} · +${rep} REP`, 3200);
}
function talkTo(npc) {
  const m = profile.mission, p = profile.phase;
  if (npc === NPC.ama) {
    if (m === 0) {
      openDialog('A strange signal', 'Ama has been tracking an encrypted pulse that appears across the city every night. Three fragments were scattered when the network failed. Find them before someone else does.', 'AMA · SIGNAL PLAZA', () => { profile.mission = 1; profile.phase = 0; updateHUD(); saveGame(true); showToast('New chapter unlocked: The Ghost Signal.'); }); return true;
    }
    if (m === 1 && p === 1) {
      openDialog('The pieces fit', 'The fragments point to an old relay beneath the harbour. Kweku knows the back roads better than anyone. Find him in the Old Quarter.', 'AMA · SIGNAL PLAZA', () => { profile.mission = 2; profile.phase = 0; completeMissionReward(150, 15, 'CHAPTER COMPLETE'); }); return true;
    }
    if (m === 5) {
      openDialog('The city wakes up', 'The network is back. Across every district, lights are returning. You did more than chase a signal — you gave the city a future. There will always be another story in Xisco City.', 'AMA · SIGNAL PLAZA', () => {
        profile.mission = 6; profile.phase = 0; profile.completed = true; completeMissionReward(1000, 60, 'XC 1 STORY COMPLETE');
        ui.endingStats.innerHTML = `<span>₵ ${profile.cash.toLocaleString('en')}</span><span>${profile.rep} REP</span><span>${Math.floor(profile.playSeconds / 60)} MIN PLAYED</span>`;
        ui.ending.classList.remove('hidden'); state.paused = true;
      }); return true;
    }
  }
  if (npc === NPC.kweku && m === 2) {
    if (p === 0 || (p === 1 && !activeChallenge)) {
      if (distanceTo(car.position, npc.position) > 25) { showToast('Bring your car to Kweku before starting the circuit.'); return true; }
      openDialog('The midnight circuit', 'Six checkpoints. No shortcuts through the water. Keep your speed up, take the corners clean and finish before the clock runs out. Bring your car close, then speak to me to start.', 'KWEKU · OLD QUARTER', () => startChallenge('race')); return true;
    }
    if (p === 2) {
      openDialog('You can drive', 'That was no beginner route. Esi at the harbour has been hearing the same signal you found. Go see what she knows.', 'KWEKU · OLD QUARTER', () => { profile.mission = 3; profile.phase = 0; completeMissionReward(700, 25, 'CIRCUIT CLEARED'); }); return true;
    }
  }
  if (npc === NPC.esi && m === 3) {
    if (p === 0) {
      openDialog('Voices from the harbour', 'The port relays were removed before the blackout. Three components are still here, but the tide and the container stacks make them hard to spot. Bring them back and we can trace the source.', 'ESI · THE HARBOUR', () => { profile.phase = 1; updateHUD(); saveGame(true); showToast('Harbour relay recovery started.'); }); return true;
    }
    if (p === 2) {
      openDialog('The route is clear', 'The fragments show a citywide relay failure. Kojo is working on the backup network in Innovation Park. Get there before the signal disappears again.', 'ESI · THE HARBOUR', () => { profile.mission = 4; profile.phase = 0; completeMissionReward(350, 20, 'HARBOUR ECHOES RECOVERED'); }); return true;
    }
  }
  if (npc === NPC.kojo && m === 4) {
    if (p === 0 || (p === 1 && !activeChallenge)) {
      if (distanceTo(car.position, npc.position) > 25) { showToast('Bring your car to Kojo before starting the blackout run.'); return true; }
      openDialog('The blackout run', 'The backup relay is on the northwest ridge. The direct route is blocked. Bring your car close, hit the relay gates in order, then reach Relay 07 before the two-minute timer runs out.', 'KOJO · INNOVATION PARK', () => startChallenge('blackout')); return true;
    }
  }
  if (npc === NPC.courier) {
    if (activeChallenge?.kind === 'courier') { showToast('Finish the delivery route first.'); return true; }
    if (distanceTo(car.position, npc.position) > 25) { showToast('Bring your car to Tariq to accept the delivery.'); return true; }
    openDialog('A quick delivery?', 'Four city checkpoints. One minute and twenty seconds. Finish the route and I will pay ₵350. Good way to learn the streets.', 'TARIQ · COURIER CONTRACT', () => startChallenge('courier')); return true;
  }
  if (npc === NPC.mechanic) {
    const hasEngine = profile.engineUpgrade, hasHandling = profile.handlingUpgrade;
    const offer = !hasEngine ? 'Engine tune: ₵600. Improves acceleration and top speed.' : !hasHandling ? 'Handling tune: ₵450. Improves steering response and cornering.' : 'Your car is tuned. Both upgrades are installed.';
    openDialog('Meko’s Motor Works', offer, 'MEKO · INNOVATION PARK', () => {
      if (!hasEngine && profile.cash >= 600) { profile.cash -= 600; profile.engineUpgrade = true; showToast('Engine tuning installed.'); sound('complete'); }
      else if (!hasEngine) showToast('You need ₵600 for the engine tune.');
      else if (!hasHandling && profile.cash >= 450) { profile.cash -= 450; profile.handlingUpgrade = true; showToast('Handling upgrade installed.'); sound('complete'); }
      else if (!hasHandling) showToast('You need ₵450 for the handling upgrade.');
      updateHUD(); saveGame(true);
    }); return true;
  }
  return false;
}

function startChallenge(kind) {
  const routes = {
    race: { label: 'MIDNIGHT CIRCUIT', duration: 105, points: [[-20, 40], [40, 40], [120, 0], [80, -80], [0, -120], [-80, -40], [-47, -40]].map(p => V(...p)), reward: 700 },
    blackout: { label: 'BLACKOUT RUN', duration: 125, points: [[-80, 120], [0, 120], [40, 80], [80, 40], [80, -40], [0, -120], [-120, -120]].map(p => V(...p)), reward: 600 },
    courier: { label: 'COURIER CONTRACT', duration: 80, points: [[80, -40], [120, 40], [40, 120], [-40, 40]].map(p => V(...p)), reward: 350 },
  };
  const route = routes[kind]; if (!route) return;
  activeChallenge = { kind, label: route.label, duration: route.duration, remaining: route.duration, points: route.points, index: 0, reward: route.reward };
  if (kind === 'race') profile.phase = 1;
  if (kind === 'blackout') profile.phase = 1;
  updateHUD(); saveGame(true); sound('engine');
  showToast(kind === 'courier' ? 'Delivery started. Checkpoints are marked.' : 'Challenge started. Follow the checkpoint markers!', 2600);
}
function failChallenge() {
  const kind = activeChallenge?.kind; activeChallenge = null; sound('fail'); updateHUD(); saveGame(true);
  if (kind === 'courier') showToast('Delivery timed out. Tariq can give you another route.');
  else showToast('Time expired. Return to the contact to try again.');
}
function finishChallenge() {
  const c = activeChallenge; if (!c) return; activeChallenge = null;
  if (c.kind === 'race') { profile.phase = 2; completeMissionReward(700, 25, 'MIDNIGHT CIRCUIT WON'); }
  else if (c.kind === 'blackout') { profile.phase = 2; completeMissionReward(600, 30, 'BACKUP ROUTE SECURED'); }
  else if (c.kind === 'courier') { profile.courierWins += 1; completeMissionReward(350, 8, 'DELIVERY COMPLETE'); }
  updateHUD(); saveGame(true);
}
let challengeUiAccumulator = 0;
function tickChallenge(dt) {
  if (!activeChallenge) return;
  if (!state.inCar) { ui.activityTimer.textContent = formatTime(activeChallenge.remaining); return; }
  activeChallenge.remaining -= dt;
  challengeUiAccumulator += dt;
  const point = activeChallenge.points[activeChallenge.index];
  const p = currentPosition();
  if (distanceTo(p, point) < (state.inCar ? 8.5 : 5.5)) {
    activeChallenge.index++; sound('pickup'); challengeUiAccumulator = .3;
    if (activeChallenge.index >= activeChallenge.points.length) { finishChallenge(); return; }
    showToast(`Checkpoint ${activeChallenge.index}/${activeChallenge.points.length}`, 900);
  }
  if (activeChallenge && activeChallenge.remaining <= 0) { failChallenge(); return; }
  if (challengeUiAccumulator >= .25) { challengeUiAccumulator = 0; ui.activityText.textContent = `${activeChallenge.label} · ${activeChallenge.index + 1}/${activeChallenge.points.length}`; ui.activityTimer.textContent = formatTime(activeChallenge.remaining); }
}
function collectPickup(item) {
  item.visible = false; item.group.visible = false;
  if (item.type === 'shard') {
    profile.fragments.push(item.id); profile.cash += 75; sound('pickup');
    showToast(`Signal fragment recovered · ${profile.fragments.length}/3 · +₵75`);
    if (profile.fragments.length >= 3) { profile.phase = 1; showToast('All fragments recovered. Return to Ama.', 2600); }
  } else if (item.type === 'relay') {
    profile.relays.push(item.id); profile.cash += 90; sound('pickup');
    showToast(`Harbour relay recovered · ${profile.relays.length}/3 · +₵90`);
    if (profile.relays.length >= 3) { profile.phase = 2; showToast('All relay components secured. Return to Esi.', 2600); }
  } else {
    profile.echoes.push(item.id); profile.cash += 100; profile.rep += 5; sound('complete');
    showToast(`Hidden city echo found · +₵100 · +5 REP`, 2400);
  }
  updateHUD(); saveGame(true);
}
function interact() {
  if (!state.started || state.paused || dialogOpen) return;
  if (state.inCar) {
    state.inCar = false; player.visible = true;
    player.position.copy(car.position);
    const right = new THREE.Vector3(Math.cos(car.rotation.y), 0, -Math.sin(car.rotation.y));
    player.position.addScaledVector(right, 2.4); player.rotation.y = car.rotation.y;
    showToast('You stepped out of the vehicle.'); return;
  }
  if (near(car.position, 4.2)) {
    state.inCar = true; player.visible = false; state.cameraYaw = car.rotation.y;
    showToast('Vehicle entered. Find your line and drive.'); sound('engine'); return;
  }
  const fragment = profile.mission === 1 && profile.phase === 0 ? findNearbyPickup(signalFragments, 3.4) : null; if (fragment) { collectPickup(fragment); return; }
  const relay = profile.mission === 3 && profile.phase === 1 ? findNearbyPickup(harbourRelays, 3.4) : null; if (relay) { collectPickup(relay); return; }
  const echo = findNearbyPickup(cityEchoes, 3.4); if (echo) { collectPickup(echo); return; }
  const npc = nearbyNPC(); if (npc && talkTo(npc)) return;
  if (near(safehouse, 5)) { saveGame(); sound('tap'); return; }
  if (near(V(42, 105), 7)) { talkTo(NPC.mechanic); return; }
  if (profile.mission === 4 && profile.phase === 2 && near(V(-120, -120), 9)) {
    openDialog('Relay 07 restored', 'The final relay comes alive. Across Xisco City, lights return and the hidden signal dissolves into a clear message: the network belongs to everyone who keeps it connected.', 'CITY NETWORK', () => {
      profile.mission = 5; profile.phase = 0; completeMissionReward(500, 35, 'CITY NETWORK RESTORED');
    }); return;
  }
  showToast('Nothing to interact with here. Follow the objective marker.');
}

function getDirectionForCamera(yaw) {
  const forward = new THREE.Vector3(Math.sin(yaw), 0, Math.cos(yaw));
  const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  return { forward, right };
}
function updatePlayer(dt, now) {
  let ix = state.joyX, iy = state.joyY;
  if (state.keys.KeyA || state.keys.ArrowLeft) ix -= 1;
  if (state.keys.KeyD || state.keys.ArrowRight) ix += 1;
  if (state.keys.KeyW || state.keys.ArrowUp) iy -= 1;
  if (state.keys.KeyS || state.keys.ArrowDown) iy += 1;
  const len = Math.hypot(ix, iy); if (len > 1) { ix /= len; iy /= len; }
  if (state.inCar) {
    const throttle = -iy, steer = ix;
    const acceleration = profile.engineUpgrade ? 21 : 17;
    const maxSpeed = profile.engineUpgrade ? 31 : 24;
    state.carSpeed += throttle * acceleration * dt;
    if (state.boost && state.carSpeed > .5) state.carSpeed += 11 * dt;
    state.carSpeed *= Math.pow(state.brake ? .88 : .986, dt * 60);
    state.carSpeed = clamp(state.carSpeed, -9, maxSpeed);
    const steerStrength = (profile.handlingUpgrade ? .92 : .72) + Math.abs(state.carSpeed) * (profile.handlingUpgrade ? .052 : .042);
    car.rotation.y += steer * dt * steerStrength * Math.sign(state.carSpeed || 1);
    const dx = Math.sin(car.rotation.y) * state.carSpeed * dt;
    const dz = Math.cos(car.rotation.y) * state.carSpeed * dt;
    const moved = moveWithCollision(car, dx, dz, 2.05);
    if (moved < Math.hypot(dx, dz) * .3 && Math.abs(state.carSpeed) > 2) state.carSpeed *= -.18;
    for (const wheel of carModel.wheels) wheel.rotation.x -= state.carSpeed * dt * 1.8;
    state.cameraYaw = THREE.MathUtils.damp(state.cameraYaw, car.rotation.y, 4, dt);
  } else {
    const { forward, right } = getDirectionForCamera(state.cameraYaw);
    const move = right.multiplyScalar(ix).add(forward.multiplyScalar(-iy));
    const moving = move.lengthSq() > .001;
    if (moving) {
      move.normalize();
      const speed = state.sprint || state.keys.ShiftLeft || state.keys.ShiftRight ? 8.7 : 4.5;
      player.rotation.y = Math.atan2(move.x, move.z);
      moveWithCollision(player, move.x * speed * dt, move.z * speed * dt, .65);
    }
    state.jumpVelocity -= 13.5 * dt;
    player.position.y += state.jumpVelocity * dt;
    if (player.position.y < 0) { player.position.y = 0; state.jumpVelocity = 0; }
    const swing = moving ? Math.sin(now * .012) * .42 : 0;
    playerModel.parts.leftLeg.rotation.x = swing; playerModel.parts.rightLeg.rotation.x = -swing;
    playerModel.parts.leftArm.rotation.x = -swing * .75; playerModel.parts.rightArm.rotation.x = swing * .75;
  }
  const runButton = $('run-btn'); runButton.textContent = state.inCar ? 'BOOST' : 'RUN';
  $('jump-btn').textContent = state.inCar ? 'BRAKE' : 'JUMP';
}
function updateNPCs(dt) {
  for (const p of pedestrians) {
    const target = p.route[p.routeIndex];
    const dx = target.x - p.npc.group.position.x, dz = target.z - p.npc.group.position.z;
    const d = Math.hypot(dx, dz);
    if (d < .8) p.routeIndex = (p.routeIndex + 1) % p.route.length;
    else {
      p.npc.group.position.x += dx / d * p.speed * dt;
      p.npc.group.position.z += dz / d * p.speed * dt;
      p.npc.group.rotation.y = Math.atan2(dx, dz);
    }
  }
  for (const t of traffic) {
    const goal = t.path[(t.pathIndex + 1) % t.path.length];
    const dx = goal[0] - t.model.group.position.x, dz = goal[1] - t.model.group.position.z;
    const d = Math.hypot(dx, dz);
    if (d < 2.5) t.pathIndex = (t.pathIndex + 1) % t.path.length;
    else {
      t.model.group.position.x += dx / d * t.speed * dt;
      t.model.group.position.z += dz / d * t.speed * dt;
      t.model.group.rotation.y = Math.atan2(dx, dz);
      for (const wheel of t.model.wheels) wheel.rotation.x -= t.speed * dt * 1.3;
    }
  }
}
function updatePickups(dt, now) {
  [...signalFragments, ...harbourRelays, ...cityEchoes].forEach((item, i) => {
    if (!item.visible) return;
    item.group.position.y = .12 + Math.sin(now * .002 + i) * .14;
    item.group.rotation.y += dt * .65;
  });
}
function updateMarker(now) {
  let target = activeChallenge ? (state.inCar ? activeChallenge.points[activeChallenge.index] : car.position) : nearestTarget();
  if (!target) { targetMarker.visible = false; return; }
  targetMarker.visible = true; targetMarker.position.set(target.x, .05 + Math.sin(now * .003) * .12, target.z);
  targetMarker.rotation.y = now * .0004;
}
function updateClock(dt) {
  state.clockMinutes = (state.clockMinutes + dt * 2.3) % 1440;
  const hours = Math.floor(state.clockMinutes / 60), mins = Math.floor(state.clockMinutes % 60);
  ui.clock.textContent = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
  const daylight = clamp(Math.sin(((state.clockMinutes - 360) / 720) * Math.PI), 0, 1);
  sun.intensity = .24 + daylight * 2.05; hemi.intensity = .55 + daylight * 1.45;
  const sky = new THREE.Color(0x101d32).lerp(new THREE.Color(0x92aaa4), daylight);
  scene.background.copy(sky); scene.fog.color.copy(sky);
  const angle = (state.clockMinutes / 1440) * Math.PI * 2;
  sun.position.set(Math.cos(angle) * 110, 24 + daylight * 105, Math.sin(angle) * 110);
  ui.timeLabel.textContent = daylight > .68 ? 'DAYLIGHT · 29°C' : daylight > .28 ? 'GOLDEN HOUR · 26°C' : 'NIGHTFALL · 23°C';
  ui.weather.textContent = daylight > .68 ? 'COASTAL SUN' : daylight > .28 ? 'WARM EVENING' : 'CITY AFTER DARK';
  ui.weatherIcon.textContent = daylight > .5 ? '☀' : '☾';
}

// Minimap: real roads and objective markers, with a readable north-up layout.
const mapCtx = ui.minimap.getContext('2d');
function mapPoint(x, z) { const s = ui.minimap.width / 360; return [(x + 180) * s, (z + 180) * s]; }
function drawMinimap() {
  const c = ui.minimap, w = c.width, h = c.height;
  mapCtx.clearRect(0, 0, w, h); mapCtx.fillStyle = '#274142'; mapCtx.fillRect(0, 0, w, h);
  mapCtx.fillStyle = '#687971';
  for (let p = -160; p <= 160; p += 40) { const [x, y] = mapPoint(p, p); mapCtx.fillRect(x - 3, 0, 6, h); mapCtx.fillRect(0, y - 3, w, 6); }
  mapCtx.fillStyle = '#236b78'; const [wx, wy] = mapPoint(155, 30); mapCtx.fillRect(wx, wy, w - wx, h - wy);
  // Coloured district hints.
  mapCtx.fillStyle = 'rgba(199,243,107,.10)'; let p = mapPoint(-140, -140); mapCtx.fillRect(p[0], p[1], 100, 100);
  mapCtx.fillStyle = 'rgba(244,199,119,.13)'; p = mapPoint(45, 40); mapCtx.fillRect(p[0], p[1], 120, 120);
  const drawDot = (pos, color, radius) => { const [x, y] = mapPoint(pos.x, pos.z); mapCtx.fillStyle = color; mapCtx.beginPath(); mapCtx.arc(x, y, radius, 0, Math.PI * 2); mapCtx.fill(); };
  for (const item of signalFragments) if (item.visible) drawDot(item.position, '#8be4d3', 3.5);
  for (const item of harbourRelays) if (item.visible) drawDot(item.position, '#f4c777', 3.5);
  for (const item of cityEchoes) if (item.visible) drawDot(item.position, '#e7ad59', 2.3);
  if (activeChallenge) drawDot(state.inCar ? activeChallenge.points[activeChallenge.index] : car.position, '#ff775f', 4.2); else drawDot(nearestTarget(), '#c7f36b', 4.2);
  const pos = currentPosition(), [px, py] = mapPoint(pos.x, pos.z);
  mapCtx.save(); mapCtx.translate(px, py); mapCtx.rotate(-(state.inCar ? car.rotation.y : player.rotation.y));
  mapCtx.fillStyle = '#fff'; mapCtx.beginPath(); mapCtx.moveTo(0, -7); mapCtx.lineTo(5, 5); mapCtx.lineTo(0, 3); mapCtx.lineTo(-5, 5); mapCtx.closePath(); mapCtx.fill(); mapCtx.restore();
}
function updateCoordinates() {
  const p = currentPosition(); const col = Math.floor((p.x + 180) / 40), row = Math.floor((p.z + 180) / 40);
  ui.coords.textContent = `SECTOR ${String.fromCharCode(65 + clamp(col, 0, 8))}${clamp(row + 1, 1, 9)} · ${Math.round(p.x)} / ${Math.round(p.z)}`;
}

// Touch and keyboard input. Screen-right maps to world-right; vehicle steering uses the same sign convention.
const joyZone = $('joystick-zone'), joyKnob = $('joystick-knob');
let joyPointer = null;
function moveJoy(e) {
  const rect = joyZone.querySelector('.joystick-base').getBoundingClientRect();
  let dx = e.clientX - (rect.left + rect.width / 2), dy = e.clientY - (rect.top + rect.height / 2);
  const max = 34, len = Math.hypot(dx, dy); if (len > max) { dx = dx / len * max; dy = dy / len * max; }
  state.joyX = clamp(dx / max, -1, 1); state.joyY = clamp(dy / max, -1, 1);
  joyKnob.style.transform = `translate(${dx}px,${dy}px)`;
}
function releaseJoy(e) {
  if (joyPointer === e.pointerId) { joyPointer = null; state.joyX = 0; state.joyY = 0; joyKnob.style.transform = 'translate(0,0)'; }
}
joyZone.addEventListener('pointerdown', e => { e.preventDefault(); joyPointer = e.pointerId; joyZone.setPointerCapture(e.pointerId); moveJoy(e); });
joyZone.addEventListener('pointermove', e => { if (e.pointerId === joyPointer) moveJoy(e); });
joyZone.addEventListener('pointerup', releaseJoy); joyZone.addEventListener('pointercancel', releaseJoy);
joyZone.addEventListener('lostpointercapture', () => { joyPointer = null; state.joyX = state.joyY = 0; joyKnob.style.transform = 'translate(0,0)'; });
function bindHold(id, down, up) {
  const el = $(id); let pointer = null;
  el.addEventListener('pointerdown', e => { e.preventDefault(); pointer = e.pointerId; el.setPointerCapture(e.pointerId); down(); });
  const end = e => { if (pointer === null || e.pointerId === pointer) { pointer = null; up(); } };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end); el.addEventListener('lostpointercapture', () => { pointer = null; up(); });
}
bindHold('run-btn', () => { if (state.inCar) state.boost = true; else state.sprint = true; }, () => { state.boost = false; state.sprint = false; });
bindHold('jump-btn', () => { if (state.inCar) state.brake = true; else if (state.started && !state.paused && !dialogOpen && player.position.y <= .02) state.jumpVelocity = 5.5; }, () => { state.brake = false; });
$('action-btn').addEventListener('click', interact);
window.addEventListener('keydown', e => {
  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
  state.keys[e.code] = true;
  if (e.code === 'KeyE' && !e.repeat) interact();
  if (e.code === 'Escape' && !e.repeat) {
    if (dialogOpen || !ui.ending.classList.contains('hidden')) return;
    if (!ui.settings.classList.contains('hidden')) { ui.settings.classList.add('hidden'); ui.pause.classList.remove('hidden'); state.paused = true; return; }
    if (!ui.journal.classList.contains('hidden')) { ui.journal.classList.add('hidden'); ui.pause.classList.remove('hidden'); state.paused = true; return; }
    state.paused ? resumeGame() : pauseGame();
  }
  if (e.code === 'KeyJ' && !e.repeat && state.started && !state.paused) openJournal();
});
window.addEventListener('keyup', e => { state.keys[e.code] = false; });
let lookPointer = null, lastLookX = 0, lastLookY = 0;
renderer.domElement.addEventListener('pointerdown', e => {
  if (e.pointerType === 'mouse' || e.clientY < innerHeight * .65) { lookPointer = e.pointerId; lastLookX = e.clientX; lastLookY = e.clientY; renderer.domElement.setPointerCapture(e.pointerId); }
});
renderer.domElement.addEventListener('pointermove', e => {
  if (lookPointer !== e.pointerId) return;
  const dx = e.clientX - lastLookX, dy = e.clientY - lastLookY; lastLookX = e.clientX; lastLookY = e.clientY;
  state.cameraYaw -= dx * .004 * settings.sensitivity;
  state.cameraPitch = clamp(state.cameraPitch + dy * .002 * settings.sensitivity, -.08, .72);
});
renderer.domElement.addEventListener('pointerup', e => { if (lookPointer === e.pointerId) lookPointer = null; });
renderer.domElement.addEventListener('pointercancel', () => { lookPointer = null; });

// Menus, save flow and chapter journal.
function openJournal() {
  state.paused = true; ui.pause.classList.add('hidden'); ui.journal.classList.remove('hidden');
  ui.journalContent.innerHTML = chapterNames.map((name, i) => {
    const status = i < profile.mission ? 'COMPLETE' : i === profile.mission ? 'IN PROGRESS' : 'LOCKED';
    const desc = i < profile.mission ? 'Chapter completed.' : i === profile.mission ? missionObjective() : chapterDescriptions[i];
    return `<article class="journal-item ${i < profile.mission ? 'done' : ''}"><strong>${String(i + 1).padStart(2, '0')} · ${name}</strong><p>${status} — ${desc}</p></article>`;
  }).join('') + `<article class="journal-item"><strong>CITY ECHOES</strong><p>${profile.echoes.length} / ${cityEchoes.length} hidden echoes recovered.</p></article>`;
}
$('journal-close').addEventListener('click', () => { ui.journal.classList.add('hidden'); ui.pause.classList.remove('hidden'); });
$('log-btn').addEventListener('click', openJournal);
$('settings-btn').addEventListener('click', () => { ui.pause.classList.add('hidden'); ui.settings.classList.remove('hidden'); });
$('settings-close').addEventListener('click', () => { ui.settings.classList.add('hidden'); ui.pause.classList.remove('hidden'); });
$('quality-setting').value = settings.quality; $('sensitivity-setting').value = Math.round(settings.sensitivity * 100); $('sound-setting').value = settings.sound ? 'on' : 'off'; $('audio-btn').textContent = `SOUND: ${settings.sound ? 'ON' : 'OFF'}`;
function saveSettings() {
  settings.quality = $('quality-setting').value;
  settings.sensitivity = Number($('sensitivity-setting').value) / 100;
  settings.sound = $('sound-setting').value === 'on'; state.soundOn = settings.sound;
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)); } catch { /* Settings remain active for this session. */ }
  applyRendererSettings(); sun.castShadow = renderer.shadowMap.enabled;
}
$('quality-setting').addEventListener('change', saveSettings); $('sensitivity-setting').addEventListener('input', saveSettings); $('sound-setting').addEventListener('change', saveSettings);
$('audio-btn').addEventListener('click', () => { state.soundOn = !state.soundOn; settings.sound = state.soundOn; $('sound-setting').value = state.soundOn ? 'on' : 'off'; $('audio-btn').textContent = `SOUND: ${state.soundOn ? 'ON' : 'OFF'}`; saveSettings(); });
ui.startBtn.addEventListener('click', newGame); ui.continueBtn.addEventListener('click', continueGame);
ui.resumeBtn.addEventListener('click', resumeGame); ui.pauseBtn.addEventListener('click', pauseGame);
$('save-btn').addEventListener('click', () => saveGame());
$('home-btn').addEventListener('click', () => { saveGame(true); state.started = false; state.paused = false; ui.pause.classList.add('hidden'); ui.start.classList.remove('hidden'); updateMenuButtons(); });
$('dialog-continue').addEventListener('click', closeDialog);
$('free-roam-btn').addEventListener('click', () => { ui.ending.classList.add('hidden'); state.paused = false; saveGame(true); showToast('Free roam unlocked. The city is yours to explore.'); });
updateMenuButtons(); updateHUD();

// Main simulation loop.
let previous = performance.now();
function animate(now) {
  requestAnimationFrame(animate);
  const dt = Math.min((now - previous) / 1000, .04); previous = now;
  if (!state.started || state.paused || dialogOpen || !ui.ending.classList.contains('hidden')) { renderer.render(scene, camera); return; }
  state.elapsed += dt;
  updateClock(dt);
  updatePlayer(dt, now);
  updateNPCs(dt);
  updatePickups(dt, now);
  tickChallenge(dt);
  updateMarker(now);
  const target = currentPosition();
  const yaw = state.inCar ? car.rotation.y : state.cameraYaw;
  const distance = state.inCar ? 12.5 : 8.6;
  const height = state.inCar ? 6.2 : 5.5;
  const desired = new THREE.Vector3(target.x - Math.sin(yaw) * distance, target.y + height + state.cameraPitch * 4, target.z - Math.cos(yaw) * distance);
  camera.position.lerp(desired, 1 - Math.pow(.001, dt)); camera.lookAt(target.x, target.y + 1.15, target.z);
  updateDistrict(); ui.mode.textContent = state.inCar ? 'IN VEHICLE' : 'ON FOOT'; ui.hint.textContent = getHint();
  updateCoordinates(); drawMinimap();
  if (performance.now() - state.toastUntil > 0) ui.toast.classList.remove('show');
  if (now - lastSavedAt > 45000) saveGame(true);
  renderer.render(scene, camera);
}
requestAnimationFrame(animate);
function resize() { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); applyRendererSettings(); }
window.addEventListener('resize', resize);
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { if (state.started && !state.paused && !dialogOpen) saveGame(true); state.keys = Object.create(null); state.joyX = state.joyY = 0; state.sprint = state.boost = state.brake = false; }
  previous = performance.now();
});
window.addEventListener('beforeunload', () => { if (state.started) saveGame(true); });
if ('serviceWorker' in navigator && location.protocol.startsWith('http')) window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));

// Initial placement and map/HUD state.
camera.position.set(0, 7, -11); camera.lookAt(player.position.x, 1.1, player.position.z);
updateMenuButtons(); updateHUD(); drawMinimap();
